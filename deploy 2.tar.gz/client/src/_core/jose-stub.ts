// Stub vazio para substituir jose no frontend
// jose só é usado no backend e não deve estar no bundle do frontend
export {};

