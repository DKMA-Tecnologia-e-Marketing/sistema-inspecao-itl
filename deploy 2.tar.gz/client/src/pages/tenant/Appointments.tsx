import TenantLayout from "@/components/TenantLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc";
import { Calendar, Search, Filter, Eye, Plus, Car, User, CheckCircle, Building2 } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { APPOINTMENT_STATUS, INSPECTION_SCOPE_TYPES } from "@shared/constants";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";

export default function TenantAppointments() {
  const { data: user } = trpc.auth.me.useQuery();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [newVehicleDialogOpen, setNewVehicleDialogOpen] = useState(false);
  const [newInspectionDialogOpen, setNewInspectionDialogOpen] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState<number | null>(null);
  
  // Form data for new vehicle
  const [vehicleData, setVehicleData] = useState({
    placa: "",
    renavam: "",
    chassi: "",
    marca: "",
    modelo: "",
    ano: undefined as number | undefined,
    cor: "",
  });
  const [customerData, setCustomerData] = useState({
    nome: "",
    cpf: "",
    email: "",
    telefone: "",
  });

  // Form data for new inspection
  const [selectedInspectionType, setSelectedInspectionType] = useState<number | null>(null);
  const [selectedInspectionLine, setSelectedInspectionLine] = useState<number | null>(null);
  const [observacoes, setObservacoes] = useState("");
  const [billToCompany, setBillToCompany] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | null>(null);

  const { data: appointments, isLoading, refetch: refetchAppointments } = trpc.appointments.listByTenant.useQuery(
    { tenantId: user?.tenantId! },
    { enabled: !!user?.tenantId }
  );

  const { data: inspectionTypePricing } = trpc.inspectionTypePricing.listByTenant.useQuery(
    { tenantId: user?.tenantId },
    { enabled: !!user?.tenantId }
  );
  const { data: inspectionLines } = trpc.inspectionLines.listByTenant.useQuery(
    { tenantId: user?.tenantId },
    { enabled: !!user?.tenantId }
  );
  const { data: companies } = trpc.companies.listByTenant.useQuery(
    { tenantId: user?.tenantId || 0 },
    { enabled: !!user?.tenantId }
  );

  const consultarInfosimples = trpc.vehicles.consultarInfosimples.useMutation();
  const createCustomer = trpc.customers.create.useMutation();
  const createVehicle = trpc.vehicles.create.useMutation();
  const createAppointment = trpc.appointments.create.useMutation();
  const createInvoice = trpc.invoices.create.useMutation();
  const utils = trpc.useUtils();

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pendente: { variant: "secondary" as const, label: APPOINTMENT_STATUS.pendente },
      confirmado: { variant: "default" as const, label: APPOINTMENT_STATUS.confirmado },
      realizado: { variant: "outline" as const, label: APPOINTMENT_STATUS.realizado },
      cancelado: { variant: "destructive" as const, label: APPOINTMENT_STATUS.cancelado },
    };
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pendente;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const filteredAppointments = (appointments || []).filter((appointment) => {
    const matchesStatus = statusFilter === "all" || appointment.status === statusFilter;
    const matchesSearch =
      !searchTerm ||
      appointment.id.toString().includes(searchTerm) ||
      appointment.observacoes?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleConsultVehicle = async () => {
    if (!vehicleData.placa || !vehicleData.renavam) {
      toast.error("Preencha a placa e o Renavam");
      return;
    }

    try {
      const dados = await consultarInfosimples.mutateAsync({
        placa: vehicleData.placa,
        renavam: vehicleData.renavam,
      });

      if (dados.dados) {
        setVehicleData({
          ...vehicleData,
          marca: dados.dados.marca || vehicleData.marca,
          modelo: dados.dados.modelo || vehicleData.modelo,
          ano: dados.dados.ano || dados.dados.anoModelo || vehicleData.ano,
          cor: dados.dados.cor || vehicleData.cor,
          chassi: dados.dados.chassi || vehicleData.chassi,
        });
        toast.success("Dados do veículo consultados com sucesso!");
      }
    } catch (error: any) {
      console.error("Erro ao consultar Infosimples:", error);
      toast.error("Erro ao consultar dados do veículo");
    }
  };

  const handleSubmitNewVehicle = async () => {
    if (!user?.tenantId) {
      toast.error("Erro ao identificar o estabelecimento.");
      return;
    }

    // Validar campos obrigatórios
    if (!vehicleData.placa || !vehicleData.renavam) {
      toast.error("Preencha a placa e o Renavam do veículo");
      return;
    }

    if (!customerData.nome || !customerData.cpf || !customerData.email || !customerData.telefone) {
      toast.error("Preencha todos os dados do cliente");
      return;
    }

    try {
      // Criar cliente
      const customer = await createCustomer.mutateAsync({
        nome: customerData.nome,
        cpf: customerData.cpf,
        email: customerData.email,
        telefone: customerData.telefone,
      });
      if (!customer || !customer.id) {
        throw new Error("Erro ao criar cliente");
      }

      // Criar veículo
      const vehicle = await createVehicle.mutateAsync({
        placa: vehicleData.placa.toUpperCase(),
        renavam: vehicleData.renavam,
        chassi: vehicleData.chassi.toUpperCase() || undefined,
        marca: vehicleData.marca || undefined,
        modelo: vehicleData.modelo || undefined,
        ano: vehicleData.ano || undefined,
        cor: vehicleData.cor || undefined,
        customerId: customer.id,
      });
      if (!vehicle || !vehicle.id) {
        throw new Error("Erro ao criar veículo");
      }

      toast.success("Veículo cadastrado com sucesso!");

      // Limpar formulário
      setVehicleData({
        placa: "",
        renavam: "",
        chassi: "",
        marca: "",
        modelo: "",
        ano: undefined,
        cor: "",
      });
      setCustomerData({
        nome: "",
        cpf: "",
        email: "",
        telefone: "",
      });
      setNewVehicleDialogOpen(false);

      // Abrir modal de inspeção com o veículo selecionado
      setSelectedVehicleId(vehicle.id);
      setNewInspectionDialogOpen(true);
    } catch (error: any) {
      toast.error("Erro ao cadastrar veículo: " + error.message);
    }
  };

  const handleSubmitNewInspection = async () => {
    if (!user?.tenantId) {
      toast.error("Erro ao identificar o estabelecimento.");
      return;
    }

    if (!selectedVehicleId) {
      toast.error("Selecione um veículo");
      return;
    }

    if (!selectedInspectionType) {
      toast.error("Selecione um tipo de inspeção");
      return;
    }

    if (!selectedInspectionLine) {
      toast.error("Selecione uma linha de inspeção");
      return;
    }

    if (billToCompany && !selectedCompanyId) {
      toast.error("Selecione uma empresa para faturamento");
      return;
    }

    try {
      // Buscar o escopo de inspeção baseado no tipo de inspeção
      // Primeiro, buscar o tipo de inspeção para pegar o scope relacionado
      const inspectionType = inspectionTypePricing?.find((p) => p.type.id === selectedInspectionType);
      if (!inspectionType) {
        throw new Error("Tipo de inspeção não encontrado");
      }

      // Buscar scope - usar o primeiro scope ativo disponível
      // TODO: Implementar lógica mais específica se necessário
      const scopes = await utils.client.inspectionScopes.list.fetch();
      const scope = scopes?.find((s) => s.ativo) || scopes?.[0];
      if (!scope) {
        throw new Error("Nenhum escopo de inspeção disponível");
      }

      // Criar inspeção com data/hora atual (agora)
      const dataHora = new Date();

      // Buscar customerId do veículo
      const vehicle = await utils.client.vehicles.getById.fetch({ id: selectedVehicleId });
      if (!vehicle) {
        throw new Error("Veículo não encontrado");
      }

      // Criar agendamento
      const appointment = await createAppointment.mutateAsync({
        tenantId: user.tenantId,
        customerId: vehicle.customerId,
        vehicleId: selectedVehicleId,
        inspectionScopeId: scope.id,
        dataAgendamento: dataHora,
        observacoes: observacoes || undefined,
      });
      if (!appointment || !appointment.id) {
        throw new Error("Erro ao criar inspeção");
      }

      toast.success("Inspeção criada com sucesso!");

      // Se for faturamento à empresa, criar fatura
      if (billToCompany && selectedCompanyId) {
        const valor = inspectionType.precoAtual || 0;

        // Criar fatura
        await createInvoice.mutateAsync({
          tenantId: user.tenantId,
          companyId: selectedCompanyId,
          valorTotal: valor,
          appointmentIds: [appointment.id],
        });

        toast.success("Fatura criada e vinculada à empresa!");
      }

      // Limpar formulário
      setSelectedVehicleId(null);
      setSelectedInspectionType(null);
      setSelectedInspectionLine(null);
      setObservacoes("");
      setBillToCompany(false);
      setSelectedCompanyId(null);
      setNewInspectionDialogOpen(false);

      // Atualizar lista
      refetchAppointments();
    } catch (error: any) {
      toast.error("Erro ao criar inspeção: " + error.message);
    }
  };

  return (
    <TenantLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Inspeções</h2>
            <p className="text-muted-foreground">Gerencie as inspeções do seu estabelecimento</p>
          </div>
          <div className="flex gap-2">
            <Dialog open={newVehicleDialogOpen} onOpenChange={setNewVehicleDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Car className="mr-2 h-4 w-4" />
                  Cadastrar Veículo
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Cadastrar Veículo</DialogTitle>
                  <DialogDescription>Cadastre um novo veículo e cliente</DialogDescription>
                </DialogHeader>

              <div className="space-y-6 py-4">
                {/* Dados do Veículo */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Car className="h-5 w-5" />
                    <h3 className="text-lg font-semibold">Dados do Veículo</h3>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="placa">Placa *</Label>
                      <Input
                        id="placa"
                        placeholder="ABC-1234"
                        value={vehicleData.placa}
                        onChange={(e) => setVehicleData({ ...vehicleData, placa: e.target.value.toUpperCase() })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="renavam">Renavam *</Label>
                      <Input
                        id="renavam"
                        placeholder="00000000000"
                        value={vehicleData.renavam}
                        onChange={(e) => setVehicleData({ ...vehicleData, renavam: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="chassi">Chassi</Label>
                      <Input
                        id="chassi"
                        placeholder="9BWZZZ377VT004251"
                        value={vehicleData.chassi}
                        onChange={(e) => setVehicleData({ ...vehicleData, chassi: e.target.value.toUpperCase() })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="marca">Marca</Label>
                      <Input
                        id="marca"
                        value={vehicleData.marca}
                        onChange={(e) => setVehicleData({ ...vehicleData, marca: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="modelo">Modelo</Label>
                      <Input
                        id="modelo"
                        value={vehicleData.modelo}
                        onChange={(e) => setVehicleData({ ...vehicleData, modelo: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="ano">Ano</Label>
                        <Input
                          id="ano"
                          type="number"
                          value={vehicleData.ano || ""}
                          onChange={(e) =>
                            setVehicleData({ ...vehicleData, ano: e.target.value ? parseInt(e.target.value) : undefined })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cor">Cor</Label>
                        <Input
                          id="cor"
                          value={vehicleData.cor}
                          onChange={(e) => setVehicleData({ ...vehicleData, cor: e.target.value })}
                        />
                      </div>
                    </div>
                  </div>
                  <Button type="button" variant="outline" onClick={handleConsultVehicle} disabled={consultarInfosimples.isPending}>
                    {consultarInfosimples.isPending ? "Consultando..." : "Consultar Dados do Veículo"}
                  </Button>
                </div>

                {/* Dados do Cliente */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    <h3 className="text-lg font-semibold">Dados do Cliente</h3>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="nome">Nome Completo *</Label>
                      <Input
                        id="nome"
                        value={customerData.nome}
                        onChange={(e) => setCustomerData({ ...customerData, nome: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cpf">CPF *</Label>
                      <Input
                        id="cpf"
                        placeholder="000.000.000-00"
                        value={customerData.cpf}
                        onChange={(e) => setCustomerData({ ...customerData, cpf: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={customerData.email}
                        onChange={(e) => setCustomerData({ ...customerData, email: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="telefone">Telefone *</Label>
                      <Input
                        id="telefone"
                        placeholder="(00) 00000-0000"
                        value={customerData.telefone}
                        onChange={(e) => setCustomerData({ ...customerData, telefone: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setNewVehicleDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleSubmitNewVehicle}
                  disabled={createCustomer.isPending || createVehicle.isPending}
                >
                  {createVehicle.isPending ? "Cadastrando..." : "Cadastrar Veículo"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={newInspectionDialogOpen} onOpenChange={setNewInspectionDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Inspeção
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Nova Inspeção</DialogTitle>
                <DialogDescription>Crie uma nova inspeção para um veículo cadastrado</DialogDescription>
              </DialogHeader>

              <div className="space-y-6 py-4">
                {/* Seleção de Veículo */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Car className="h-5 w-5" />
                    <h3 className="text-lg font-semibold">Veículo</h3>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="vehicle">Placa do Veículo *</Label>
                    <Input
                      id="vehicle"
                      placeholder="Digite a placa do veículo para buscar..."
                      value={vehicleData.placa}
                      onChange={(e) => setVehicleData({ ...vehicleData, placa: e.target.value.toUpperCase() })}
                      onBlur={async () => {
                        if (vehicleData.placa) {
                          try {
                            const vehicle = await utils.client.vehicles.getByPlaca.fetch({ placa: vehicleData.placa });
                            if (vehicle) {
                              setSelectedVehicleId(vehicle.id);
                              toast.success("Veículo encontrado!");
                            } else {
                              toast.error("Veículo não encontrado. Cadastre o veículo primeiro.");
                            }
                          } catch (error) {
                            toast.error("Erro ao buscar veículo");
                          }
                        }
                      }}
                    />
                    <p className="text-xs text-muted-foreground">
                      {selectedVehicleId ? "✓ Veículo selecionado" : "Digite a placa e pressione Tab para buscar"}
                    </p>
                  </div>
                </div>

                {/* Tipo de Inspeção e Linha */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <h3 className="text-lg font-semibold">Inspeção</h3>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="inspectionType">Tipo de Inspeção *</Label>
                      <Select
                        value={selectedInspectionType?.toString()}
                        onValueChange={(value) => setSelectedInspectionType(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione..." />
                        </SelectTrigger>
                        <SelectContent>
                          {inspectionTypePricing?.map((pricing) => (
                            <SelectItem key={pricing.type.id} value={pricing.type.id.toString()}>
                              {pricing.type.nome} - R$ {(pricing.precoAtual / 100).toFixed(2).replace(".", ",")}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="inspectionLine">Linha de Inspeção *</Label>
                      <Select
                        value={selectedInspectionLine?.toString()}
                        onValueChange={(value) => setSelectedInspectionLine(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione..." />
                        </SelectTrigger>
                        <SelectContent>
                          {inspectionLines?.map((line) => (
                            <SelectItem key={line.id} value={line.id.toString()}>
                              {line.nome || `Linha ${line.id}`} - {line.tipo}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="observacoes">Observações</Label>
                    <textarea
                      id="observacoes"
                      className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      value={observacoes}
                      onChange={(e) => setObservacoes(e.target.value)}
                      placeholder="Observações adicionais..."
                    />
                  </div>
                </div>

                {/* Faturamento */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    <h3 className="text-lg font-semibold">Faturamento</h3>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="billToCompany"
                        checked={billToCompany}
                        onCheckedChange={(checked) => {
                          setBillToCompany(checked as boolean);
                          if (!checked) {
                            setSelectedCompanyId(null);
                          }
                        }}
                      />
                      <Label htmlFor="billToCompany" className="cursor-pointer">
                        Faturar para empresa
                      </Label>
                    </div>
                    {billToCompany && (
                      <div className="space-y-2">
                        <Label htmlFor="company">Empresa *</Label>
                        <Select
                          value={selectedCompanyId?.toString()}
                          onValueChange={(value) => setSelectedCompanyId(parseInt(value))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione a empresa..." />
                          </SelectTrigger>
                          <SelectContent>
                            {companies?.map((company) => (
                              <SelectItem key={company.id} value={company.id.toString()}>
                                {company.nome}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setNewInspectionDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleSubmitNewInspection}
                  disabled={createAppointment.isPending}
                >
                  {createAppointment.isPending ? "Criando..." : "Criar Inspeção"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">Buscar</label>
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por ID ou observações..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Status</label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    {Object.entries(APPOINTMENT_STATUS).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Appointments Table */}
        <Card>
          <CardHeader>
            <CardTitle>Inspeções</CardTitle>
            <CardDescription>{filteredAppointments.length} agendamento(s) encontrado(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredAppointments.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Nenhum agendamento encontrado</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Data/Hora</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Veículo</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAppointments.map((appointment) => (
                      <TableRow key={appointment.id}>
                        <TableCell className="font-medium">#{appointment.id}</TableCell>
                        <TableCell>
                          {format(new Date(appointment.dataAgendamento), "dd/MM/yyyy 'às' HH:mm", {
                            locale: ptBR,
                          })}
                        </TableCell>
                        <TableCell>-</TableCell>
                        <TableCell>-</TableCell>
                        <TableCell>{getStatusBadge(appointment.status)}</TableCell>
                        <TableCell className="text-right">
                          <Link href={`/admin/appointments/detail?id=${appointment.id}`}>
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              Ver
                            </Button>
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </TenantLayout>
  );
}

