import TenantLayout from "@/components/TenantLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Building2, Plus, DollarSign, FileText, QrCode, Receipt } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";

const formatCurrency = (value: number) => `R$ ${(value / 100).toFixed(2).replace(".", ",")}`;

export default function Financial() {
  const { data: user } = trpc.auth.me.useQuery();
  const [companyDialogOpen, setCompanyDialogOpen] = useState(false);
  const [invoiceDialogOpen, setInvoiceDialogOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<number | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<number | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<"pix" | "boleto" | "">("");
  const [selectedAppointments, setSelectedAppointments] = useState<number[]>([]);

  const [companyForm, setCompanyForm] = useState({
    nome: "",
    cnpj: "",
    razaoSocial: "",
    email: "",
    telefone: "",
    endereco: "",
    cidade: "",
    estado: "",
    cep: "",
  });

  // Queries
  const { data: companies, refetch: refetchCompanies } = trpc.companies.listByTenant.useQuery(
    { tenantId: user?.tenantId || 0 },
    { enabled: !!user?.tenantId }
  );

  const { data: pendingInvoices, refetch: refetchInvoices } = trpc.invoices.listPendingByTenant.useQuery(
    { tenantId: user?.tenantId || 0 },
    { enabled: !!user?.tenantId }
  );

  const { data: appointments } = trpc.appointments.listByTenant.useQuery(
    { tenantId: user?.tenantId || 0 },
    { enabled: !!user?.tenantId }
  );

  const { data: inspectionTypePricing } = trpc.inspectionTypePricing.listByTenant.useQuery(
    { tenantId: user?.tenantId },
    { enabled: !!user?.tenantId }
  );

  // Buscar inspeções já faturadas para filtrar
  const { data: allInvoices } = trpc.invoices.listByTenant.useQuery(
    { tenantId: user?.tenantId || 0 },
    { enabled: !!user?.tenantId }
  );

  // Mutations
  const createCompany = trpc.companies.create.useMutation({
    onSuccess: () => {
      toast.success("Empresa cadastrada com sucesso!");
      setCompanyDialogOpen(false);
      setCompanyForm({
        nome: "",
        cnpj: "",
        razaoSocial: "",
        email: "",
        telefone: "",
        endereco: "",
        cidade: "",
        estado: "",
        cep: "",
      });
      refetchCompanies();
    },
    onError: (error) => toast.error("Erro ao cadastrar empresa: " + error.message),
  });

  const createInvoice = trpc.invoices.create.useMutation({
    onSuccess: () => {
      toast.success("Fatura criada com sucesso!");
      setInvoiceDialogOpen(false);
      setSelectedCompany(null);
      refetchInvoices();
    },
    onError: (error) => toast.error("Erro ao criar fatura: " + error.message),
  });

  const closeInvoice = trpc.invoices.close.useMutation({
    onSuccess: (data) => {
      toast.success("Fatura fechada com sucesso!");
      setPaymentDialogOpen(false);
      setSelectedInvoice(null);
      setPaymentMethod("");
      refetchInvoices();
      // Aqui você pode mostrar o QR Code ou Boleto baseado no paymentMethod
      if (paymentMethod === "pix" && data.qrCode) {
        // Mostrar QR Code
        toast.info("QR Code PIX gerado! (mockado)");
      } else if (paymentMethod === "boleto" && data.boletoUrl) {
        // Mostrar Boleto
        toast.info("Boleto gerado! (mockado)");
      }
    },
    onError: (error) => toast.error("Erro ao fechar fatura: " + error.message),
  });

  const handleCreateCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.tenantId) {
      toast.error("Erro ao identificar o estabelecimento.");
      return;
    }
    if (!companyForm.nome) {
      toast.error("Informe o nome da empresa.");
      return;
    }

    createCompany.mutate({
      tenantId: user.tenantId,
      ...companyForm,
    });
  };

  const handleCloseInvoice = () => {
    if (!selectedInvoice || !paymentMethod) {
      toast.error("Selecione uma forma de pagamento.");
      return;
    }

    closeInvoice.mutate({
      invoiceId: selectedInvoice,
      formaPagamento: paymentMethod as "pix" | "boleto",
    });
  };

  const handleCreateInvoice = () => {
    if (!selectedCompany || selectedAppointments.length === 0) {
      toast.error("Selecione uma empresa e pelo menos uma inspeção.");
      return;
    }
    if (!user?.tenantId) {
      toast.error("Erro ao identificar o estabelecimento.");
      return;
    }

    // Calcular valor total baseado nos preços reais
    const valorTotal = selectedTotal;

    createInvoice.mutate({
      tenantId: user.tenantId,
      companyId: selectedCompany,
      valorTotal,
      appointmentIds: selectedAppointments,
    });

    setInvoiceDialogOpen(false);
    setSelectedCompany(null);
    setSelectedAppointments([]);
  };

  // Filtrar inspeções não faturadas (apenas as realizadas)
  const availableAppointments = (appointments || []).filter(
    (appointment) => appointment.status === "realizado"
  );

  // Função para obter preço de uma inspeção
  const getAppointmentPrice = (appointmentId: number) => {
    const appointment = appointments?.find((a) => a.id === appointmentId);
    if (!appointment || !appointment.inspectionTypeId) return 0;
    const pricing = inspectionTypePricing?.find((p) => p.type.id === appointment.inspectionTypeId);
    return pricing?.precoAtual || 0;
  };

  // Calcular total das inspeções selecionadas
  const selectedTotal = selectedAppointments.reduce((sum, id) => sum + getAppointmentPrice(id), 0);

  // Agrupar inspeções por empresa
  const invoicesByCompany = (pendingInvoices || []).reduce((acc, invoice) => {
    const companyId = invoice.companyId;
    if (!acc[companyId]) {
      acc[companyId] = {
        company: companies?.find((c) => c.id === companyId),
        invoices: [],
        total: 0,
      };
    }
    acc[companyId].invoices.push(invoice);
    acc[companyId].total += invoice.valorTotal;
    return acc;
  }, {} as Record<number, { company: typeof companies[0] | undefined; invoices: typeof pendingInvoices; total: number }>);

  return (
    <TenantLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Financeiro</h2>
            <p className="text-muted-foreground">Gerencie empresas e faturas de inspeções</p>
          </div>
          <Dialog open={companyDialogOpen} onOpenChange={setCompanyDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Empresa
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleCreateCompany}>
                <DialogHeader>
                  <DialogTitle>Cadastrar Empresa</DialogTitle>
                  <DialogDescription>Cadastre uma nova empresa para faturamento</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome">Nome Fantasia *</Label>
                    <Input
                      id="nome"
                      value={companyForm.nome}
                      onChange={(e) => setCompanyForm({ ...companyForm, nome: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="razaoSocial">Razão Social</Label>
                    <Input
                      id="razaoSocial"
                      value={companyForm.razaoSocial}
                      onChange={(e) => setCompanyForm({ ...companyForm, razaoSocial: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cnpj">CNPJ</Label>
                    <Input
                      id="cnpj"
                      value={companyForm.cnpj}
                      onChange={(e) => setCompanyForm({ ...companyForm, cnpj: e.target.value })}
                      placeholder="00.000.000/0000-00"
                    />
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        type="email"
                        value={companyForm.email}
                        onChange={(e) => setCompanyForm({ ...companyForm, email: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="telefone">Telefone</Label>
                      <Input
                        id="telefone"
                        value={companyForm.telefone}
                        onChange={(e) => setCompanyForm({ ...companyForm, telefone: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endereco">Endereço</Label>
                    <Input
                      id="endereco"
                      value={companyForm.endereco}
                      onChange={(e) => setCompanyForm({ ...companyForm, endereco: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <Label htmlFor="cidade">Cidade</Label>
                      <Input
                        id="cidade"
                        value={companyForm.cidade}
                        onChange={(e) => setCompanyForm({ ...companyForm, cidade: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="estado">Estado</Label>
                      <Input
                        id="estado"
                        value={companyForm.estado}
                        onChange={(e) => setCompanyForm({ ...companyForm, estado: e.target.value })}
                        maxLength={2}
                        placeholder="SP"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cep">CEP</Label>
                      <Input
                        id="cep"
                        value={companyForm.cep}
                        onChange={(e) => setCompanyForm({ ...companyForm, cep: e.target.value })}
                        placeholder="00000-000"
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setCompanyDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={createCompany.isPending}>
                    Cadastrar
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Lista de Empresas */}
        <Card>
          <CardHeader>
            <CardTitle>Empresas Cadastradas</CardTitle>
            <CardDescription>Empresas que podem ter inspeções faturadas</CardDescription>
          </CardHeader>
          <CardContent>
            {!companies || companies.length === 0 ? (
              <p className="py-8 text-center text-muted-foreground">Nenhuma empresa cadastrada.</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>CNPJ</TableHead>
                      <TableHead>E-mail</TableHead>
                      <TableHead>Telefone</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {companies.map((company) => (
                      <TableRow key={company.id}>
                        <TableCell className="font-medium">{company.nome}</TableCell>
                        <TableCell>{company.cnpj || "-"}</TableCell>
                        <TableCell>{company.email || "-"}</TableCell>
                        <TableCell>{company.telefone || "-"}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedCompany(company.id);
                              setSelectedAppointments([]);
                              setInvoiceDialogOpen(true);
                            }}
                          >
                            <FileText className="mr-2 h-4 w-4" />
                            Vincular Inspeções
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Faturas Pendentes por Empresa */}
        <Card>
          <CardHeader>
            <CardTitle>Faturas Pendentes</CardTitle>
            <CardDescription>Inspeções agrupadas por empresa e total a pagar</CardDescription>
          </CardHeader>
          <CardContent>
            {!pendingInvoices || pendingInvoices.length === 0 ? (
              <p className="py-8 text-center text-muted-foreground">Nenhuma fatura pendente.</p>
            ) : (
              <div className="space-y-6">
                {Object.values(invoicesByCompany).map((group) => (
                  <Card key={group.company?.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            <Building2 className="h-5 w-5" />
                            {group.company?.nome || "Empresa não encontrada"}
                          </CardTitle>
                          <CardDescription>
                            {group.invoices.length} inspeção(ões) • Total: {formatCurrency(group.total)}
                          </CardDescription>
                        </div>
                        <Button
                          onClick={() => {
                            // Pegar o primeiro invoice ID do grupo (todos são da mesma empresa)
                            const firstInvoice = group.invoices[0];
                            if (firstInvoice) {
                              setSelectedInvoice(firstInvoice.id);
                              setPaymentDialogOpen(true);
                            }
                          }}
                        >
                          <Receipt className="mr-2 h-4 w-4" />
                          Fechar Fatura
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Número</TableHead>
                              <TableHead>Data</TableHead>
                              <TableHead>Valor</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {group.invoices.map((invoice) => (
                              <TableRow key={invoice.id}>
                                <TableCell className="font-medium">#{invoice.numero}</TableCell>
                                <TableCell>
                                  {new Date(invoice.createdAt).toLocaleDateString("pt-BR")}
                                </TableCell>
                                <TableCell>{formatCurrency(invoice.valorTotal)}</TableCell>
                                <TableCell>
                                  <Badge variant={invoice.status === "pendente" ? "secondary" : "default"}>
                                    {invoice.status}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Dialog para Vincular Inspeções */}
        <Dialog open={invoiceDialogOpen} onOpenChange={setInvoiceDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Vincular Inspeções à Empresa</DialogTitle>
              <DialogDescription>
                Selecione as inspeções que serão faturadas para {companies?.find((c) => c.id === selectedCompany)?.nome}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {availableAppointments.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Nenhuma inspeção disponível para faturamento.
                </p>
              ) : (
                <div className="space-y-2 max-h-[400px] overflow-y-auto">
                  {availableAppointments.map((appointment) => (
                    <div
                      key={appointment.id}
                      className="flex items-center space-x-2 rounded-lg border p-3 hover:bg-accent"
                    >
                      <Checkbox
                        id={`appointment-${appointment.id}`}
                        checked={selectedAppointments.includes(appointment.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedAppointments([...selectedAppointments, appointment.id]);
                          } else {
                            setSelectedAppointments(selectedAppointments.filter((id) => id !== appointment.id));
                          }
                        }}
                      />
                      <label
                        htmlFor={`appointment-${appointment.id}`}
                        className="flex-1 cursor-pointer text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-semibold">Inspeção #{appointment.id}</span>
                            <span className="ml-2 text-xs text-muted-foreground">
                              {new Date(appointment.dataAgendamento).toLocaleDateString("pt-BR")}
                            </span>
                          </div>
                          <span className="text-sm font-medium">{formatCurrency(getAppointmentPrice(appointment.id))}</span>
                        </div>
                      </label>
                    </div>
                  ))}
                </div>
              )}
              {selectedAppointments.length > 0 && (
                <div className="rounded-lg border p-4 bg-muted/40">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Total selecionado:</span>
                    <span className="text-lg font-bold">
                      {formatCurrency(selectedTotal)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {selectedAppointments.length} inspeção(ões) selecionada(s)
                  </p>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setInvoiceDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreateInvoice} disabled={selectedAppointments.length === 0 || createInvoice.isPending}>
                Criar Fatura
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog para Fechar Fatura */}
        <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Fechar Fatura</DialogTitle>
              <DialogDescription>Selecione a forma de pagamento</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Forma de Pagamento *</Label>
                <Select value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as "pix" | "boleto")}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pix">
                      <div className="flex items-center gap-2">
                        <QrCode className="h-4 w-4" />
                        PIX
                      </div>
                    </SelectItem>
                    <SelectItem value="boleto">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Boleto
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {paymentMethod === "pix" && (
                <div className="rounded-lg border p-4 bg-muted/40">
                  <p className="text-sm text-muted-foreground">
                    O QR Code PIX será gerado após confirmar. (Mockado - integração com Asaas em desenvolvimento)
                  </p>
                </div>
              )}
              {paymentMethod === "boleto" && (
                <div className="rounded-lg border p-4 bg-muted/40">
                  <p className="text-sm text-muted-foreground">
                    O boleto será gerado após confirmar. (Mockado - integração com Asaas em desenvolvimento)
                  </p>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setPaymentDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCloseInvoice} disabled={!paymentMethod || closeInvoice.isPending}>
                Confirmar e Gerar {paymentMethod === "pix" ? "PIX" : "Boleto"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TenantLayout>
  );
}

