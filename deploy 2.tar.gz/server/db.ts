import { eq, and, desc, asc, sql, gte, lte, like, isNull } from "drizzle-orm";
import { delete as drizzleDelete } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  tenants,
  InsertTenant,
  Tenant,
  customers,
  InsertCustomer,
  Customer,
  vehicles,
  InsertVehicle,
  Vehicle,
  serviceCategories,
  InsertServiceCategory,
  ServiceCategory,
  services,
  InsertService,
  Service,
  inspectionScopes,
  InsertInspectionScope,
  InspectionScope,
  inspectionScopeServices,
  InsertInspectionScopeService,
  inspectionTypes,
  InsertInspectionType,
  inspectionLines,
  InsertInspectionLine,
  inspectionLineCapabilities,
  InsertInspectionLineCapability,
  inspectionTypePrices,
  inspectionTypeTenants,
  InsertInspectionTypeTenant,
  InspectionTypeTenant,
  priceConfigurations,
  InsertPriceConfiguration,
  PriceConfiguration,
  detranAuthorizations,
  InsertDetranAuthorization,
  DetranAuthorization,
  appointments,
  InsertAppointment,
  Appointment,
  payments,
  InsertPayment,
  Payment,
  paymentSplits,
  InsertPaymentSplit,
  PaymentSplit,
  splitConfigurations,
  InsertSplitConfiguration,
  SplitConfiguration,
  roles,
  InsertRole,
  Role,
  permissions,
  InsertPermission,
  Permission,
  rolePermissions,
  InsertRolePermission,
  auditLogs,
  InsertAuditLog,
  AuditLog,
  whatsappMessages,
  InsertWhatsappMessage,
  WhatsappMessage,
  financialReconciliations,
  InsertFinancialReconciliation,
  FinancialReconciliation,
  reports,
  InsertReport,
  Report,
  companies,
  InsertCompany,
  Company,
  invoices,
  InsertInvoice,
  Invoice,
  invoiceAppointments,
  InsertInvoiceAppointment,
  InvoiceAppointment,
  userGroups,
  InsertUserGroup,
  UserGroup,
  groupMenuPermissions,
  InsertGroupMenuPermission,
  GroupMenuPermission,
  reconciliationConfig,
  InsertReconciliationConfig,
  ReconciliationConfig,
  reconciliations,
  InsertReconciliation,
  Reconciliation,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db) {
    if (!process.env.DATABASE_URL) {
      console.error("[Database] ❌ DATABASE_URL não está definida!");
      console.error("[Database] Configure DATABASE_URL no arquivo .env ou .env.production");
      return null;
    }
    
    try {
      console.log("[Database] 🔌 Conectando ao banco de dados...");
      console.log("[Database] URL:", process.env.DATABASE_URL.replace(/:[^:@]+@/, ":****@"));
      _db = drizzle(process.env.DATABASE_URL);
      
      // Testar conexão fazendo uma query simples
      await _db.execute(sql`SELECT 1`);
      console.log("[Database] ✅ Conexão estabelecida com sucesso!");
    } catch (error: any) {
      console.error("[Database] ❌ Falha ao conectar:", error?.message || error);
      console.error("[Database] Stack:", error?.stack);
      _db = null;
    }
  }
  return _db;
}

// ============= USER QUERIES =============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (user.tenantId !== undefined) {
      values.tenantId = user.tenantId;
      updateSet.tenantId = user.tenantId;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserPassword(userId: number, passwordHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, userId));
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(users).orderBy(desc(users.createdAt));
}

export async function getUsersByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(users).where(eq(users.tenantId, tenantId)).orderBy(desc(users.createdAt));
}

// ============= TENANT QUERIES =============

// Helper para verificar se um valor deve ser incluído no insert
function shouldIncludeValue(value: unknown): boolean {
  if (value === undefined) return false;
  if (value === null) return true; // null é válido para campos opcionais
  if (typeof value === "string" && value.trim() === "") return false; // Omitir strings vazias
  return true;
}

export async function createTenant(tenant: InsertTenant) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Declarar variáveis no escopo da função para que estejam disponíveis no catch
  let values: {
    nome: string;
    cnpj: string;
    telefone?: string | null;
    email?: string | null;
    endereco?: string | null;
    cidade?: string | null;
    estado?: string | null;
    cep?: string | null;
    latitude?: string | null;
    longitude?: string | null;
    asaasWalletId?: string | null;
  } | undefined;
  
  let insertValues: Record<string, unknown> | undefined;

  try {
    // Construir objeto de valores explicitamente, incluindo apenas campos com valores válidos
    // IMPORTANTE: Não usar Partial<InsertTenant> ou cast, pois isso pode fazer o Drizzle incluir todos os campos
    values = {
      nome: tenant.nome,
      cnpj: tenant.cnpj,
    };

    // Adicionar campos opcionais apenas se tiverem valores válidos (não undefined e não string vazia)
    if (tenant.telefone !== undefined && tenant.telefone !== null && tenant.telefone.trim() !== "") {
      values.telefone = tenant.telefone;
    }
    if (tenant.email !== undefined && tenant.email !== null && tenant.email.trim() !== "") {
      values.email = tenant.email;
    }
    if (tenant.endereco !== undefined && tenant.endereco !== null && tenant.endereco.trim() !== "") {
      values.endereco = tenant.endereco;
    }
    if (tenant.cidade !== undefined && tenant.cidade !== null && tenant.cidade.trim() !== "") {
      values.cidade = tenant.cidade;
    }
    if (tenant.estado !== undefined && tenant.estado !== null && tenant.estado.trim() !== "") {
      values.estado = tenant.estado;
    }
    if (tenant.cep !== undefined && tenant.cep !== null && tenant.cep.trim() !== "") {
      values.cep = tenant.cep;
    }
    // latitude, longitude e asaasWalletId: omitir completamente se vazios ou undefined
    if (tenant.latitude !== undefined && tenant.latitude !== null && tenant.latitude.trim() !== "") {
      values.latitude = tenant.latitude;
    }
    if (tenant.longitude !== undefined && tenant.longitude !== null && tenant.longitude.trim() !== "") {
      values.longitude = tenant.longitude;
    }
    if (tenant.asaasWalletId !== undefined && tenant.asaasWalletId !== null && tenant.asaasWalletId.trim() !== "") {
      values.asaasWalletId = tenant.asaasWalletId;
    }

    console.log("[Database] Creating tenant with values:", {
      nome: values.nome,
      cnpj: values.cnpj ? `${String(values.cnpj).substring(0, 5)}...` : null,
      optionalFieldsCount: Object.keys(values).length - 2, // menos nome e cnpj
      hasLatitude: "latitude" in values,
      hasLongitude: "longitude" in values,
      hasAsaasWalletId: "asaasWalletId" in values,
      allKeys: Object.keys(values),
      valuesObject: JSON.stringify(values),
    });

    // CRÍTICO: Criar um novo objeto apenas com as chaves que realmente queremos inserir
    // Isso garante que campos undefined não sejam incluídos
    insertValues = {};
    insertValues.nome = values.nome;
    insertValues.cnpj = values.cnpj;
    
    // Adicionar apenas campos que existem no objeto values
    if ("telefone" in values) insertValues.telefone = values.telefone;
    if ("email" in values) insertValues.email = values.email;
    if ("endereco" in values) insertValues.endereco = values.endereco;
    if ("cidade" in values) insertValues.cidade = values.cidade;
    if ("estado" in values) insertValues.estado = values.estado;
    if ("cep" in values) insertValues.cep = values.cep;
    if ("latitude" in values) insertValues.latitude = values.latitude;
    if ("longitude" in values) insertValues.longitude = values.longitude;
    if ("asaasWalletId" in values) insertValues.asaasWalletId = values.asaasWalletId;

    console.log("[Database] Final insert values:", {
      keys: Object.keys(insertValues),
      count: Object.keys(insertValues).length,
      values: insertValues,
    });

    // CRÍTICO: Adicionar campos com default explicitamente
    // O Drizzle não deve usar "default" como valor, mas sim valores explícitos
    insertValues.ativo = true; // Campo obrigatório com default no schema
    insertValues.createdAt = new Date(); // Campo obrigatório com default no schema
    insertValues.updatedAt = new Date(); // Campo obrigatório com default no schema
    
    // Inserir usando o objeto limpo
    console.log("[Database] Executando insert com valores:", JSON.stringify(insertValues, null, 2));
    console.log("[Database] Tipos dos valores:", Object.entries(insertValues).map(([k, v]) => `${k}: ${typeof v} (${v === null ? 'null' : v})`));
    
    try {
      const [result] = await db.insert(tenants).values(insertValues);
      const tenantId = Number(result.insertId);
      
      console.log("[Database] Tenant created with ID:", tenantId);
      
      // Retornar o tenant criado
      const createdTenant = await getTenantById(tenantId);
      if (!createdTenant) {
        throw new Error(`Failed to retrieve created tenant with ID ${tenantId}`);
      }
      return createdTenant;
    } catch (insertError: any) {
      // Log específico do erro de insert
      console.error("[Database] Erro durante insert:", insertError);
      console.error("[Database] Insert error message:", insertError?.message);
      console.error("[Database] Insert error code:", insertError?.code);
      console.error("[Database] Insert error sqlMessage:", insertError?.sqlMessage);
      console.error("[Database] Insert error sql:", insertError?.sql);
      throw insertError; // Re-throw para ser capturado pelo catch externo
    }
  } catch (error: any) {
    // Log completo do erro do banco de dados
    console.error("========================================");
    console.error("[Database] ❌ ERRO COMPLETO ao criar tenant:");
    console.error("[Database] Error message:", error?.message);
    console.error("[Database] Error code:", error?.code);
    console.error("[Database] Error errno:", error?.errno);
    console.error("[Database] Error sqlState:", error?.sqlState);
    console.error("[Database] Error sqlMessage:", error?.sqlMessage);
    console.error("[Database] Error sql:", error?.sql);
    console.error("[Database] Error stack:", error?.stack);
    
    // Log detalhado de todas as propriedades do erro
    console.error("[Database] Todas as propriedades do erro:", Object.keys(error || {}));
    if (error?.cause) {
      console.error("[Database] Error cause:", error.cause);
    }
    if (error?.originalError) {
      console.error("[Database] Original error:", error.originalError);
    }
    
    // Tentar extrair mensagem SQL mais específica
    const sqlError = error?.sqlMessage || error?.message || error?.toString();
    console.error("[Database] SQL Error Message (prioritário):", sqlError);
    
    // Log dos dados recebidos
    console.error("[Database] Dados recebidos do frontend:", {
      nome: tenant.nome,
      cnpj: tenant.cnpj,
      telefone: tenant.telefone || "(empty/undefined)",
      email: tenant.email || "(empty/undefined)",
      endereco: tenant.endereco || "(empty/undefined)",
      cidade: tenant.cidade || "(empty/undefined)",
      estado: tenant.estado || "(empty/undefined)",
      cep: tenant.cep || "(empty/undefined)",
      latitude: tenant.latitude || "(empty/undefined)",
      longitude: tenant.longitude || "(empty/undefined)",
      asaasWalletId: tenant.asaasWalletId || "(empty/undefined)",
    });
    
    // Log dos valores que tentaram ser inseridos
    console.error("[Database] Valores que tentaram ser inseridos:", {
      valuesObject: values ? Object.keys(values) : "values não disponível",
      insertValuesAvailable: insertValues !== undefined,
      insertValuesKeys: insertValues ? Object.keys(insertValues) : "insertValues não disponível",
      insertValuesContent: insertValues || "insertValues não disponível",
    });
    console.error("========================================");
    
    // Re-throw com mensagem mais detalhada
    const errorMessage = error?.sqlMessage || error?.message || "Erro desconhecido ao criar tenant";
    const detailedError = new Error(`Failed to create tenant: ${errorMessage}${error?.code ? ` (Code: ${error.code})` : ""}`);
    (detailedError as any).originalError = error;
    throw detailedError;
  }
}

export async function getTenantById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(tenants).where(eq(tenants.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllTenants() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(tenants).orderBy(asc(tenants.nome));
}

export async function getActiveTenants() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(tenants).where(eq(tenants.ativo, true)).orderBy(asc(tenants.nome));
}

export async function updateTenant(id: number, data: Partial<InsertTenant>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(tenants).set(data).where(eq(tenants.id, id));
}

export async function deleteTenant(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(tenants).where(eq(tenants.id, id));
}

export async function getTenantByLocation(latitude: string, longitude: string) {
  const db = await getDb();
  if (!db) return undefined;

  // Simplified location matching - in production, use geospatial queries
  const result = await db
    .select()
    .from(tenants)
    .where(and(eq(tenants.ativo, true), eq(tenants.latitude, latitude), eq(tenants.longitude, longitude)))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============= CUSTOMER QUERIES =============

export async function createCustomer(customer: InsertCustomer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(customers).values(customer);
  const customerId = Number(result.insertId);
  return await getCustomerById(customerId);
}

export async function getCustomerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCustomerByCpf(cpf: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(customers).where(eq(customers.cpf, cpf)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCustomerByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(customers).where(eq(customers.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateCustomer(id: number, data: Partial<InsertCustomer>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(customers).set(data).where(eq(customers.id, id));
}

/**
 * Retorna apenas os clientes que têm agendamentos com o tenant especificado
 */
export async function getCustomersByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  // Buscar todos os agendamentos do tenant
  const appointments = await getAppointmentsByTenant(tenantId);
  
  // Extrair IDs únicos dos clientes
  const customerIds = [...new Set(appointments.map((apt) => apt.customerId))];

  if (customerIds.length === 0) {
    return [];
  }

  // Buscar os clientes
  const allCustomers = [];
  for (const customerId of customerIds) {
    const customer = await getCustomerById(customerId);
    if (customer) {
      allCustomers.push(customer);
    }
  }

  return allCustomers;
}

// ============= VEHICLE QUERIES =============

export async function createVehicle(vehicle: InsertVehicle) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(vehicles).values(vehicle);
  const vehicleId = Number(result.insertId);
  return await getVehicleById(vehicleId);
}

export async function getVehicleById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(vehicles).where(eq(vehicles.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getVehicleByPlaca(placa: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(vehicles).where(eq(vehicles.placa, placa)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getVehiclesByCustomer(customerId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(vehicles).where(eq(vehicles.customerId, customerId)).orderBy(desc(vehicles.createdAt));
}

// ============= SERVICE CATEGORY QUERIES =============

export async function createServiceCategory(category: InsertServiceCategory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(serviceCategories).values(category);
}

export async function getAllServiceCategories() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(serviceCategories).orderBy(asc(serviceCategories.nome));
}

export async function getActiveServiceCategories() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(serviceCategories).where(eq(serviceCategories.ativo, true)).orderBy(asc(serviceCategories.nome));
}

export async function updateServiceCategory(id: number, data: Partial<InsertServiceCategory>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(serviceCategories).set(data).where(eq(serviceCategories.id, id));
}

// ============= SERVICE QUERIES =============

export async function createService(service: InsertService) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(services).values(service);
}

export async function getAllServices() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(services).orderBy(asc(services.nome));
}

export async function getServicesByCategory(categoryId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(services).where(eq(services.categoryId, categoryId)).orderBy(asc(services.nome));
}

export async function updateService(id: number, data: Partial<InsertService>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(services).set(data).where(eq(services.id, id));
}

// ============= INSPECTION SCOPE QUERIES =============

export async function createInspectionScope(scope: InsertInspectionScope) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(inspectionScopes).values(scope);
}

export async function getAllInspectionScopes() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(inspectionScopes).orderBy(asc(inspectionScopes.nome));
}

export async function getInspectionScopesByType(tipo: string) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(inspectionScopes).where(eq(inspectionScopes.tipo, tipo as any)).orderBy(asc(inspectionScopes.nome));
}

export async function updateInspectionScope(id: number, data: Partial<InsertInspectionScope>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(inspectionScopes).set(data).where(eq(inspectionScopes.id, id));
}

// ============= INSPECTION TYPE QUERIES =============

export async function createInspectionType(data: InsertInspectionType) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(inspectionTypes).values(data);
}

export async function getInspectionTypeById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(inspectionTypes).where(eq(inspectionTypes.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllInspectionTypes(includeInactive = false) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(inspectionTypes).orderBy(asc(inspectionTypes.nome));
  if (!includeInactive) {
    query = query.where(eq(inspectionTypes.ativo, true));
  }
  return await query;
}

/**
 * Retorna apenas os tipos de inspeção vinculados diretamente ao tenant
 */
export async function getInspectionTypesByTenant(tenantId: number, includeInactive = false) {
  const db = await getDb();
  if (!db) return [];

  // Buscar relacionamentos diretos entre tipos de inspeção e tenant
  const relationships = await db
    .select()
    .from(inspectionTypeTenants)
    .where(
      includeInactive
        ? eq(inspectionTypeTenants.tenantId, tenantId)
        : and(eq(inspectionTypeTenants.tenantId, tenantId), eq(inspectionTypeTenants.ativo, true))
    );

  if (relationships.length === 0) {
    return [];
  }

  const inspectionTypeIds = relationships.map((rel) => rel.inspectionTypeId);

  // Buscar os tipos de inspeção
  const allTypes = await getAllInspectionTypes(includeInactive);

  // Filtrar apenas os tipos vinculados ao tenant
  return allTypes.filter((type) => inspectionTypeIds.includes(type.id));
}

/**
 * Funções para gerenciar relacionamentos entre tipos de inspeção e tenants
 */
export async function getInspectionTypeTenants(inspectionTypeId: number) {
  const db = await getDb();
  if (!db) return [];

  // Buscar relacionamentos com informações do tenant
  const relationships = await db
    .select({
      id: inspectionTypeTenants.id,
      inspectionTypeId: inspectionTypeTenants.inspectionTypeId,
      tenantId: inspectionTypeTenants.tenantId,
      ativo: inspectionTypeTenants.ativo,
      createdAt: inspectionTypeTenants.createdAt,
      updatedAt: inspectionTypeTenants.updatedAt,
      tenant: {
        id: tenants.id,
        nome: tenants.nome,
        cnpj: tenants.cnpj,
      },
    })
    .from(inspectionTypeTenants)
    .innerJoin(tenants, eq(inspectionTypeTenants.tenantId, tenants.id))
    .where(and(eq(inspectionTypeTenants.inspectionTypeId, inspectionTypeId), eq(inspectionTypeTenants.ativo, true)));

  return relationships;
}

export async function linkInspectionTypeToTenant(inspectionTypeId: number, tenantId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Verificar se já existe
  const existing = await db
    .select()
    .from(inspectionTypeTenants)
    .where(
      and(
        eq(inspectionTypeTenants.inspectionTypeId, inspectionTypeId),
        eq(inspectionTypeTenants.tenantId, tenantId)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    // Atualizar para ativo
    await db
      .update(inspectionTypeTenants)
      .set({ ativo: true, updatedAt: new Date() })
      .where(eq(inspectionTypeTenants.id, existing[0].id));
    return existing[0];
  }

  // Criar novo relacionamento
  const [result] = await db
    .insert(inspectionTypeTenants)
    .values({
      inspectionTypeId,
      tenantId,
      ativo: true,
    });

  return await db
    .select()
    .from(inspectionTypeTenants)
    .where(eq(inspectionTypeTenants.id, Number(result.insertId)))
    .limit(1)
    .then((rows) => rows[0]);
}

export async function unlinkInspectionTypeFromTenant(inspectionTypeId: number, tenantId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(inspectionTypeTenants)
    .set({ ativo: false, updatedAt: new Date() })
    .where(
      and(
        eq(inspectionTypeTenants.inspectionTypeId, inspectionTypeId),
        eq(inspectionTypeTenants.tenantId, tenantId)
      )
    );
}

export async function updateInspectionType(id: number, data: Partial<InsertInspectionType>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(inspectionTypes).set(data).where(eq(inspectionTypes.id, id));
}

// ============= INSPECTION LINES QUERIES =============

export async function createInspectionLine(data: InsertInspectionLine) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(inspectionLines).values(data);
}

export async function getInspectionLineById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(inspectionLines).where(eq(inspectionLines.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getInspectionLinesByTenant(tenantId: number, includeInactive = false) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(inspectionLines.tenantId, tenantId)];
  if (!includeInactive) {
    conditions.push(eq(inspectionLines.ativo, true));
  }

  const whereClause = conditions.length === 1 ? conditions[0] : and(...conditions);

  return await db
    .select()
    .from(inspectionLines)
    .where(whereClause)
    .orderBy(asc(inspectionLines.id));
}

export async function updateInspectionLine(id: number, data: Partial<InsertInspectionLine>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(inspectionLines).set(data).where(eq(inspectionLines.id, id));
}

// ============= INSPECTION LINE CAPABILITIES QUERIES =============

export async function getCapabilitiesByInspectionLine(inspectionLineId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(inspectionLineCapabilities)
    .where(eq(inspectionLineCapabilities.inspectionLineId, inspectionLineId))
    .orderBy(asc(inspectionLineCapabilities.id));
}

export async function createInspectionLineCapability(data: InsertInspectionLineCapability) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(inspectionLineCapabilities).values(data);
}

export async function updateInspectionLineCapability(id: number, data: Partial<InsertInspectionLineCapability>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(inspectionLineCapabilities).set(data).where(eq(inspectionLineCapabilities.id, id));
}

export async function deleteInspectionLineCapability(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(inspectionLineCapabilities).where(eq(inspectionLineCapabilities.id, id));
}

// ============= INSPECTION TYPE PRICING QUERIES =============

export async function getInspectionTypePricesByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(inspectionTypePrices).where(and(eq(inspectionTypePrices.tenantId, tenantId), eq(inspectionTypePrices.ativo, true)));
}

export async function getInspectionTypePrice(tenantId: number, inspectionTypeId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(inspectionTypePrices)
    .where(
      and(eq(inspectionTypePrices.tenantId, tenantId), eq(inspectionTypePrices.inspectionTypeId, inspectionTypeId), eq(inspectionTypePrices.ativo, true))
    )
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export type SetInspectionTypePriceInput = {
  tenantId: number;
  inspectionTypeId: number;
  preco: number;
  ultimoAjustePor?: number | null;
  observacoes?: string | null;
  ativo?: boolean;
};

export async function setInspectionTypePrice(data: SetInspectionTypePriceInput) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const inspectionType = await getInspectionTypeById(data.inspectionTypeId);
  if (!inspectionType) {
    throw new Error("Tipo de inspeção não encontrado");
  }

  const minPrice = Math.max(0, inspectionType.precoBase - inspectionType.variacaoMaxima);
  const maxPrice = inspectionType.precoBase + inspectionType.variacaoMaxima;

  if (data.preco < minPrice || data.preco > maxPrice) {
    throw new Error(`Preço fora da faixa permitida (${(minPrice / 100).toFixed(2)} - ${(maxPrice / 100).toFixed(2)})`);
  }

  const existing = await getInspectionTypePrice(data.tenantId, data.inspectionTypeId);
  if (existing) {
    await db
      .update(inspectionTypePrices)
      .set({
        preco: data.preco,
        ultimoAjustePor: data.ultimoAjustePor ?? existing.ultimoAjustePor,
        observacoes: data.observacoes ?? existing.observacoes,
        updatedAt: new Date(),
        ativo: data.ativo ?? existing.ativo,
      })
      .where(eq(inspectionTypePrices.id, existing.id));
    return await getInspectionTypePrice(data.tenantId, data.inspectionTypeId);
  }

  await db.insert(inspectionTypePrices).values({
    tenantId: data.tenantId,
    inspectionTypeId: data.inspectionTypeId,
    preco: data.preco,
    ultimoAjustePor: data.ultimoAjustePor,
    observacoes: data.observacoes,
    ativo: data.ativo ?? true,
  });
  return await getInspectionTypePrice(data.tenantId, data.inspectionTypeId);
}

// ============= PRICE CONFIGURATION QUERIES =============

export async function createPriceConfiguration(config: InsertPriceConfiguration) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(priceConfigurations).values(config);
}

export async function getPriceConfigurationsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(priceConfigurations).where(eq(priceConfigurations.tenantId, tenantId));
}

export async function getPriceByTenantAndService(tenantId: number, serviceId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(priceConfigurations)
    .where(and(eq(priceConfigurations.tenantId, tenantId), eq(priceConfigurations.serviceId, serviceId), eq(priceConfigurations.ativo, true)))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updatePriceConfiguration(id: number, data: Partial<InsertPriceConfiguration>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(priceConfigurations).set(data).where(eq(priceConfigurations.id, id));
}

// ============= APPOINTMENT QUERIES =============

export async function createAppointment(appointment: InsertAppointment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(appointments).values(appointment);
  const appointmentId = Number(result.insertId);
  return await getAppointmentById(appointmentId);
}

export async function getAppointmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(appointments).where(eq(appointments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAppointmentsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(appointments).where(eq(appointments.tenantId, tenantId)).orderBy(desc(appointments.dataAgendamento));
}

export async function getAppointmentsByCustomer(customerId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(appointments).where(eq(appointments.customerId, customerId)).orderBy(desc(appointments.dataAgendamento));
}

export async function updateAppointment(id: number, data: Partial<InsertAppointment>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(appointments).set(data).where(eq(appointments.id, id));
}

// ============= PAYMENT QUERIES =============

export async function createPayment(payment: InsertPayment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(payments).values(payment);
}

export async function getPaymentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getPaymentByAppointment(appointmentId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(payments).where(eq(payments.appointmentId, appointmentId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getPaymentsByAsaasId(asaasPaymentId: string) {
  const db = await getDb();
  if (!db) return [];

  const result = await db.select().from(payments).where(eq(payments.asaasPaymentId, asaasPaymentId));
  return result;
}

export async function updatePayment(id: number, data: Partial<InsertPayment>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(payments).set(data).where(eq(payments.id, id));
}

// ============= PAYMENT SPLIT QUERIES =============

export async function createPaymentSplit(split: InsertPaymentSplit) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(paymentSplits).values(split);
}

export async function getPaymentSplitsByPayment(paymentId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(paymentSplits).where(eq(paymentSplits.paymentId, paymentId));
}

export async function getPaymentSplitsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(paymentSplits).where(eq(paymentSplits.tenantId, tenantId)).orderBy(desc(paymentSplits.createdAt));
}

// ============= SPLIT CONFIGURATION QUERIES =============

export async function createSplitConfiguration(config: InsertSplitConfiguration) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(splitConfigurations).values(config);
}

export async function getSplitConfigurationsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(splitConfigurations).where(eq(splitConfigurations.tenantId, tenantId));
}

export async function getSplitConfigByTenantAndService(tenantId: number, serviceId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(splitConfigurations)
    .where(and(eq(splitConfigurations.tenantId, tenantId), eq(splitConfigurations.serviceId, serviceId), eq(splitConfigurations.ativo, true)))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateSplitConfiguration(id: number, data: Partial<InsertSplitConfiguration>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(splitConfigurations).set(data).where(eq(splitConfigurations.id, id));
}

// ============= AUDIT LOG QUERIES =============

export async function createAuditLog(log: InsertAuditLog) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(auditLogs).values(log);
}

export async function getAuditLogsByTenant(tenantId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(auditLogs).where(eq(auditLogs.tenantId, tenantId)).orderBy(desc(auditLogs.createdAt)).limit(limit);
}

export async function getAuditLogs(filters: {
  action?: string;
  userId?: number;
  tenantId?: number | null;
  limit?: number;
} = {}) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [];

  if (filters.action) {
    conditions.push(eq(auditLogs.action, filters.action));
  }
  if (filters.userId) {
    conditions.push(eq(auditLogs.userId, filters.userId));
  }
  if (filters.tenantId !== undefined) {
    if (filters.tenantId === null) {
      conditions.push(isNull(auditLogs.tenantId));
    } else {
      conditions.push(eq(auditLogs.tenantId, filters.tenantId));
    }
  }

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  const result = await db
    .select({
      id: auditLogs.id,
      userId: auditLogs.userId,
      tenantId: auditLogs.tenantId,
      action: auditLogs.action,
      entityType: auditLogs.entityType,
      entityId: auditLogs.entityId,
      description: auditLogs.description,
      ipAddress: auditLogs.ipAddress,
      userAgent: auditLogs.userAgent,
      createdAt: auditLogs.createdAt,
    })
    .from(auditLogs)
    .where(whereClause)
    .orderBy(desc(auditLogs.createdAt))
    .limit(filters.limit || 100);

  // Enriquecer com dados de usuário e tenant
  const enrichedResult = await Promise.all(
    result.map(async (log) => {
      let userName = "Usuário desconhecido";
      let tenantName = null;

      if (log.userId) {
        const user = await getUserById(log.userId);
        userName = user?.name || userName;
      }

      if (log.tenantId) {
        const tenant = await getTenantById(log.tenantId);
        tenantName = tenant?.nome || null;
      }

      return {
        ...log,
        userName,
        tenantName,
      };
    })
  );

  return enrichedResult;
}

export async function getAuditLogsByUser(userId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(auditLogs).where(eq(auditLogs.userId, userId)).orderBy(desc(auditLogs.createdAt)).limit(limit);
}

// ============= WHATSAPP MESSAGE QUERIES =============

export async function createWhatsappMessage(message: InsertWhatsappMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(whatsappMessages).values(message);
}

export async function getWhatsappMessagesByCustomer(customerId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(whatsappMessages).where(eq(whatsappMessages.customerId, customerId)).orderBy(asc(whatsappMessages.createdAt));
}

export async function getWhatsappMessagesByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(whatsappMessages).where(eq(whatsappMessages.tenantId, tenantId)).orderBy(desc(whatsappMessages.createdAt));
}

// ============= FINANCIAL RECONCILIATION QUERIES =============

export async function createFinancialReconciliation(reconciliation: InsertFinancialReconciliation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(financialReconciliations).values(reconciliation);
}

export async function getFinancialReconciliationsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(financialReconciliations).where(eq(financialReconciliations.tenantId, tenantId)).orderBy(desc(financialReconciliations.createdAt));
}

export async function updateFinancialReconciliation(id: number, data: Partial<InsertFinancialReconciliation>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(financialReconciliations).set(data).where(eq(financialReconciliations.id, id));
}

// ============= REPORT QUERIES =============

export async function createReport(report: InsertReport) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(reports).values(report);
}

export async function getReportsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(reports).where(eq(reports.tenantId, tenantId)).orderBy(desc(reports.createdAt));
}

export async function getAllReports() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(reports).orderBy(desc(reports.createdAt));
}

// ============= COMPANY QUERIES =============

export async function createCompany(company: InsertCompany) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(companies).values(company);
  return await getCompanyById(Number(result.insertId));
}

export async function getCompanyById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(companies).where(eq(companies.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCompaniesByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(companies)
    .where(and(eq(companies.tenantId, tenantId), eq(companies.ativo, true)))
    .orderBy(asc(companies.nome));
}

export async function updateCompany(id: number, data: Partial<InsertCompany>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(companies).set({ ...data, updatedAt: new Date() }).where(eq(companies.id, id));
  return await getCompanyById(id);
}

// ============= INVOICE QUERIES =============

export async function createInvoice(invoice: InsertInvoice) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Gerar número único da fatura
  const numero = `FAT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  
  const [result] = await db.insert(invoices).values({
    ...invoice,
    numero,
  });
  
  return await getInvoiceById(Number(result.insertId));
}

export async function getInvoiceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getInvoicesByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(invoices)
    .where(eq(invoices.tenantId, tenantId))
    .orderBy(desc(invoices.createdAt));
}

export async function getPendingInvoicesByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(invoices)
    .where(and(eq(invoices.tenantId, tenantId), eq(invoices.status, "pendente")))
    .orderBy(desc(invoices.createdAt));
}

export async function closeInvoice(invoiceId: number, formaPagamento: "pix" | "boleto") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const invoice = await getInvoiceById(invoiceId);
  if (!invoice) {
    throw new Error("Fatura não encontrada");
  }

  // Gerar dados mockados
  const qrCode = formaPagamento === "pix" 
    ? `00020126400014BR.GOV.BCB.PIX0114+55819999999990208DEMONSTRATION5204000053039865405${(invoice.valorTotal / 100).toFixed(2)}5802BR5920ITL DEMO LTDA6009SAO PAULO62070503***6304ABCD`
    : null;
  
  const boletoUrl = formaPagamento === "boleto"
    ? `https://asaas.com/boleto/mock/${invoiceId}`
    : null;

  const dataVencimento = new Date();
  dataVencimento.setDate(dataVencimento.getDate() + 7); // 7 dias para vencer

  await db
    .update(invoices)
    .set({
      formaPagamento,
      qrCode,
      boletoUrl,
      dataVencimento,
      updatedAt: new Date(),
    })
    .where(eq(invoices.id, invoiceId));

  return await getInvoiceById(invoiceId);
}

export async function linkAppointmentToInvoice(invoiceId: number, appointmentId: number, valor: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(invoiceAppointments).values({
    invoiceId,
    appointmentId,
    valor,
  });
}

export async function getInvoiceAppointments(invoiceId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(invoiceAppointments)
    .where(eq(invoiceAppointments.invoiceId, invoiceId));
}

// ============= USER GROUP QUERIES =============

export async function createUserGroup(group: InsertUserGroup) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(userGroups).values(group);
  return await getUserGroupById(Number(result.insertId));
}

export async function getUserGroupById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(userGroups).where(eq(userGroups.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserGroupsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(userGroups)
    .where(and(eq(userGroups.tenantId, tenantId), eq(userGroups.ativo, true)))
    .orderBy(asc(userGroups.nome));
}

export async function updateUserGroup(id: number, data: Partial<InsertUserGroup>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(userGroups).set({ ...data, updatedAt: new Date() }).where(eq(userGroups.id, id));
  return await getUserGroupById(id);
}

export async function deleteUserGroup(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(userGroups).set({ ativo: false, updatedAt: new Date() }).where(eq(userGroups.id, id));
}

// ============= GROUP MENU PERMISSIONS QUERIES =============

export async function setGroupMenuPermissions(groupId: number, menuPaths: string[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Remover permissões existentes
  await db.delete(groupMenuPermissions).where(eq(groupMenuPermissions.groupId, groupId));

  // Adicionar novas permissões
  if (menuPaths.length > 0) {
    await db.insert(groupMenuPermissions).values(
      menuPaths.map((path) => ({
        groupId,
        menuPath: path,
      }))
    );
  }
}

export async function getGroupMenuPermissions(groupId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(groupMenuPermissions)
    .where(eq(groupMenuPermissions.groupId, groupId));
}

export async function getUserMenuPermissions(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const user = await getUserById(userId);
  if (!user || !user.groupId) return [];

  return await getGroupMenuPermissions(user.groupId);
}

// ============= RECONCILIATION CONFIG QUERIES =============

export async function getReconciliationConfig() {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(reconciliationConfig)
    .where(eq(reconciliationConfig.ativo, true))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertReconciliationConfig(config: InsertReconciliationConfig) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getReconciliationConfig();
  if (existing) {
    await db.update(reconciliationConfig).set({ ...config, updatedAt: new Date() }).where(eq(reconciliationConfig.id, existing.id));
    return await getReconciliationConfig();
  } else {
    const [result] = await db.insert(reconciliationConfig).values(config);
    return await db.select().from(reconciliationConfig).where(eq(reconciliationConfig.id, Number(result.insertId))).limit(1)[0];
  }
}

// ============= RECONCILIATION QUERIES =============

export async function createReconciliation(reconciliation: InsertReconciliation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(reconciliations).values(reconciliation);
  return await getReconciliationById(Number(result.insertId));
}

export async function getReconciliationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(reconciliations).where(eq(reconciliations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getReconciliationsByTenant(tenantId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(reconciliations)
    .where(eq(reconciliations.tenantId, tenantId))
    .orderBy(desc(reconciliations.dataConciliacao));
}

export async function updateReconciliation(id: number, data: Partial<InsertReconciliation>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(reconciliations).set({ ...data, updatedAt: new Date() }).where(eq(reconciliations.id, id));
  return await getReconciliationById(id);
}

// Buscar inspeções do dia com dados relacionados
export async function getAppointmentsByDate(tenantId: number, date: Date) {
  const db = await getDb();
  if (!db) return [];

  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);

  const appointmentsList = await db
    .select()
    .from(appointments)
    .where(
      and(
        eq(appointments.tenantId, tenantId),
        gte(appointments.createdAt, startOfDay),
        lte(appointments.createdAt, endOfDay)
      )
    )
    .orderBy(desc(appointments.createdAt));

  // Buscar dados relacionados
  const appointmentsWithData = await Promise.all(
    appointmentsList.map(async (ap) => {
      const vehicle = ap.vehicleId ? await getVehicleById(ap.vehicleId) : null;
      const inspectionType = ap.inspectionTypeId ? await getInspectionTypeById(ap.inspectionTypeId) : null;
      const inspectionLine = ap.inspectionLineId ? await getInspectionLineById(ap.inspectionLineId) : null;

      return {
        ...ap,
        vehicle,
        inspectionType,
        inspectionLine,
      };
    })
  );

  return appointmentsWithData;
}
