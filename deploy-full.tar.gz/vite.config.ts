import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { nodePolyfills } from "vite-plugin-node-polyfills";
import fs from "node:fs";
import path from "path";
import { defineConfig } from "vite";
import { cryptoPolyfillPlugin } from "./vite-crypto-plugin";

// Removido vitePluginManusRuntime completamente - estava gerando redirecionamento para /login.html
// Configurar React plugin corretamente
const plugins = [
  react({
    jsxRuntime: "automatic",
    jsxImportSource: "react",
    babel: {
      plugins: [],
    },
  }),
  tailwindcss(),
  nodePolyfills({
    // Incluir polyfills para crypto
    globals: {
      Buffer: true,
      global: true,
      process: true,
    },
    // Polyfill específico para crypto
    protocolImports: true,
  }),
  cryptoPolyfillPlugin(), // Plugin para substituir crypto por globalThis.crypto
];

export default defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
      // Polyfill para crypto - redirecionar imports de crypto para browserify
      crypto: "crypto-browserify",
    },
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "client", "public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    rollupOptions: {
      output: {
        manualChunks: undefined,
      },
    },
  },
  define: {
    global: "globalThis",
  },
  optimizeDeps: {
    exclude: ["jose"],
    include: ["crypto-browserify"],
  },
  server: {
    port: 5005,
    host: true,
    proxy: {
      "/api": {
        target: "http://localhost:5006",
        changeOrigin: true,
        secure: false,
      },
    },
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1",
    ],
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
  },
});
