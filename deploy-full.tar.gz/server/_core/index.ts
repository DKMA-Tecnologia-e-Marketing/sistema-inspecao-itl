import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerAsaasWebhook } from "./asaas-webhook";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  
  // Função para servir o index.html
  const serveIndexHtml = async (req: express.Request, res: express.Response) => {
    try {
      const fs = await import("fs");
      const path = await import("path");
      // Em produção, servir do dist/public, em desenvolvimento do client
      const templatePath = process.env.NODE_ENV === "production"
        ? path.resolve(process.cwd(), "dist", "public", "index.html")
        : path.resolve(import.meta.dirname, "../..", "client", "index.html");
      
      if (!fs.existsSync(templatePath)) {
        console.error("[Serve HTML] Template not found:", templatePath);
        res.status(404).end("Page not found");
        return;
      }
      
      const template = await fs.promises.readFile(templatePath, "utf-8");
      const modifiedTemplate = process.env.NODE_ENV === "development"
        ? template.replace(`src="/src/main.tsx"`, `src="/src/main.tsx?v=${Date.now()}"`)
        : template;
      res.removeHeader("location");
      res.status(200).set({
        "Content-Type": "text/html",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
      }).end(modifiedTemplate);
    } catch (e) {
      console.error("[Serve HTML] Error:", e);
      res.status(500).end("Error loading page");
    }
  };
  
  // Handler para raiz e login.html - PRIMEIRO, antes de QUALQUER middleware
  app.get("/", serveIndexHtml);
  app.get("/login.html", serveIndexHtml);
  
  // Configure body parser
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  
  // OAuth callback
  registerOAuthRoutes(app);
  // ASAAS Webhook
  registerAsaasWebhook(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  
  // Em desenvolvimento, não servir arquivos estáticos se o frontend estiver separado
  // O frontend Vite rodará na porta 5005 separadamente
  if (process.env.NODE_ENV !== "development") {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "5006");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`🚀 Backend API running on http://localhost:${port}/`);
    console.log(`📡 tRPC endpoint: http://localhost:${port}/api/trpc`);
  });
}

startServer().catch(console.error);
