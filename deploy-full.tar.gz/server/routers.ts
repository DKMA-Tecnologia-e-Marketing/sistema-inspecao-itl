import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Acesso negado. Apenas administradores." });
  }
  return next({ ctx });
});

// Tenant-scoped procedure (for operators)
const tenantProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!ctx.user.tenantId && ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Usuário não associado a um estabelecimento." });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async (opts) => {
      return opts.ctx.user;
    }),
    
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        console.log("[Login] Tentativa de login:", input.email);
        const user = await db.getUserByEmail(input.email);
        console.log("[Login] Usuário encontrado:", user ? `Sim (${user.email}, role: ${user.role})` : "Não");
        console.log("[Login] Tem senha:", user ? !!user.passwordHash : false);
        if (!user || !user.passwordHash) {
          console.log("[Login] Erro: usuário não encontrado ou sem senha");
          throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou senha inválidos" });
        }

        const bcrypt = await import("bcrypt");
        const isValid = await bcrypt.compare(input.password, user.passwordHash);
        console.log("[Login] Senha válida:", isValid);
        if (!isValid) {
          console.log("[Login] Erro: senha inválida");
          throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou senha inválidos" });
        }
        console.log("[Login] Login bem-sucedido para:", user.email);

        // Criar sessão
        const { sdk } = await import("./_core/sdk");
        const { ONE_YEAR_MS } = await import("@shared/const");
        const sessionToken = await sdk.createSessionToken(user.openId, {
          name: user.name || "",
          expiresInMs: ONE_YEAR_MS,
        });

        const cookieOptions = getSessionCookieOptions(ctx.req);
        const devCookieOptions = process.env.NODE_ENV === "development"
          ? { ...cookieOptions, sameSite: "lax" as const, secure: false }
          : cookieOptions;
        ctx.res.cookie(COOKIE_NAME, sessionToken, { ...devCookieOptions, maxAge: ONE_YEAR_MS });

        // Atualizar último acesso
        await db.upsertUser({
          openId: user.openId,
          lastSignedIn: new Date(),
        });

        return { success: true, user };
      }),

    setPassword: protectedProcedure
      .input(z.object({ password: z.string().min(6) }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) {
          throw new TRPCError({ code: "UNAUTHORIZED" });
        }

        const bcrypt = await import("bcrypt");
        const passwordHash = await bcrypt.hash(input.password, 10);

        await db.updateUserPassword(ctx.user.id, passwordHash);
        return { success: true };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      // Limpar cookie com todas as opções possíveis
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1, path: "/" });
      // Limpar também sem domain para garantir
      ctx.res.clearCookie(COOKIE_NAME, { path: "/", maxAge: -1 });
      // Em desenvolvimento, limpar também com sameSite: lax
      if (process.env.NODE_ENV === "development") {
        ctx.res.clearCookie(COOKIE_NAME, { path: "/", maxAge: -1, sameSite: "lax", secure: false });
      }
      return {
        success: true,
      } as const;
    }),
  }),

  // ============= TENANT ROUTES =============
  tenants: router({
    list: adminProcedure.query(async () => {
      return await db.getAllTenants();
    }),

    listActive: publicProcedure.query(async () => {
      return await db.getActiveTenants();
    }),

    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getTenantById(input.id);
    }),

    create: adminProcedure
      .input(
        z.object({
          nome: z.string(),
          cnpj: z.string(),
          telefone: z.string().optional(),
          email: z.string().email().optional(),
          endereco: z.string().optional(),
          cidade: z.string().optional(),
          estado: z.string().optional(),
          cep: z.string().optional(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
          asaasWalletId: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createTenant(input);
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          cnpj: z.string().optional(),
          telefone: z.string().optional(),
          email: z.string().email().optional(),
          endereco: z.string().optional(),
          cidade: z.string().optional(),
          estado: z.string().optional(),
          cep: z.string().optional(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
          asaasWalletId: z.string().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateTenant(id, data);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteTenant(input.id);
        return { success: true } as const;
      }),
  }),

  // ============= CUSTOMER ROUTES =============
  customers: router({
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getCustomerById(input.id);
    }),

    getByCpf: publicProcedure.input(z.object({ cpf: z.string() })).query(async ({ input }) => {
      return await db.getCustomerByCpf(input.cpf);
    }),

    getByEmail: publicProcedure.input(z.object({ email: z.string().email() })).query(async ({ input }) => {
      return await db.getCustomerByEmail(input.email);
    }),

    create: publicProcedure
      .input(
        z.object({
          nome: z.string(),
          cpf: z.string(),
          email: z.string().email().optional(),
          telefone: z.string().optional(),
          endereco: z.string().optional(),
          cep: z.string().optional(),
          cidade: z.string().optional(),
          estado: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createCustomer(input);
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          email: z.string().email().optional(),
          telefone: z.string().optional(),
          emailVerificado: z.boolean().optional(),
          telefoneVerificado: z.boolean().optional(),
          endereco: z.string().optional(),
          cep: z.string().optional(),
          cidade: z.string().optional(),
          estado: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateCustomer(id, data);
      }),

    sendEmailVerification: publicProcedure
      .input(z.object({ email: z.string().email(), customerId: z.number().optional() }))
      .mutation(async ({ input }) => {
        const token = Math.floor(100000 + Math.random() * 900000).toString();
        console.log(`[Email Verification] Token para ${input.email}: ${token}`);
        
        // Enviar e-mail com token
        try {
          const { enviarEmail, EMAIL_TEMPLATES } = await import("../integrations/email");
          await enviarEmail({
            to: input.email,
            subject: "Código de Verificação - Sistema ITL",
            html: EMAIL_TEMPLATES.tokenValidacao(token),
          });
        } catch (error: any) {
          console.error("[Email] Erro ao enviar e-mail:", error.message);
          // Continuar mesmo se falhar (em dev pode não estar configurado)
        }
        
        // TODO: Salvar token no banco com expiração
        // Por enquanto, retornar token para desenvolvimento
        return {
          success: true,
          token: process.env.NODE_ENV === "development" ? token : undefined, // Só retornar token em dev
          message: "E-mail de verificação enviado",
        };
      }),

    sendSmsVerification: publicProcedure
      .input(z.object({ telefone: z.string(), customerId: z.number().optional() }))
      .mutation(async ({ input }) => {
        const token = Math.floor(100000 + Math.random() * 900000).toString();
        console.log(`[SMS Verification] Token para ${input.telefone}: ${token}`);
        
        // Enviar SMS com token
        try {
          const { enviarSMS, SMS_TEMPLATES } = await import("../integrations/sms");
          await enviarSMS(input.telefone, SMS_TEMPLATES.tokenValidacao(token));
        } catch (error: any) {
          console.error("[SMS] Erro ao enviar SMS:", error.message);
          // Continuar mesmo se falhar (em dev pode não estar configurado)
        }
        
        // TODO: Salvar token no banco com expiração
        // Por enquanto, retornar token para desenvolvimento
        return {
          success: true,
          token: process.env.NODE_ENV === "development" ? token : undefined, // Só retornar token em dev
          message: "SMS de verificação enviado",
        };
      }),

    verifyToken: publicProcedure
      .input(
        z.object({
          customerId: z.number(),
          token: z.string(),
          type: z.enum(["email", "sms"]),
        })
      )
      .mutation(async ({ input }) => {
        // TODO: Validar token no banco de dados com expiração
        // Por enquanto, aceitar qualquer token de 6 dígitos em desenvolvimento
        if (process.env.NODE_ENV === "development") {
          // Validar formato do token (6 dígitos)
          if (!/^\d{6}$/.test(input.token)) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "Token deve ter 6 dígitos" });
          }
          
          await db.updateCustomer(input.customerId, {
            [input.type === "email" ? "emailVerificado" : "telefoneVerificado"]: true,
          });
          return { success: true, message: `${input.type === "email" ? "E-mail" : "Telefone"} verificado com sucesso` };
        }
        
        // Em produção, verificar token no banco com expiração
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Token inválido" });
      }),
  }),

  // ============= VEHICLE ROUTES =============
  vehicles: router({
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getVehicleById(input.id);
    }),

    getByPlaca: publicProcedure.input(z.object({ placa: z.string() })).query(async ({ input }) => {
      return await db.getVehicleByPlaca(input.placa);
    }),

    getByCustomer: protectedProcedure.input(z.object({ customerId: z.number() })).query(async ({ input }) => {
      return await db.getVehiclesByCustomer(input.customerId);
    }),

    consultarInfosimples: publicProcedure
      .input(z.object({ placa: z.string(), renavam: z.string().optional() }))
      .mutation(async ({ input }) => {
        const { consultarVeiculo } = await import("../integrations/infosimples");
        const dados = await consultarVeiculo(input.placa, input.renavam);
        return dados;
      }),

    create: publicProcedure
      .input(
        z.object({
          placa: z.string(),
          renavam: z.string().optional(),
          chassi: z.string().optional(),
          marca: z.string().optional(),
          modelo: z.string().optional(),
          ano: z.number().optional(),
          cor: z.string().optional(),
          customerId: z.number(),
          dadosInfosimples: z.any().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createVehicle(input);
      }),
  }),

  // ============= SERVICE CATEGORY ROUTES =============
  serviceCategories: router({
    list: publicProcedure.query(async () => {
      return await db.getAllServiceCategories();
    }),

    listActive: publicProcedure.query(async () => {
      return await db.getActiveServiceCategories();
    }),

    create: adminProcedure
      .input(
        z.object({
          nome: z.string(),
          descricao: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createServiceCategory(input);
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          descricao: z.string().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateServiceCategory(id, data);
      }),
  }),

  // ============= SERVICE ROUTES =============
  services: router({
    list: publicProcedure.query(async () => {
      return await db.getAllServices();
    }),

    listByCategory: publicProcedure.input(z.object({ categoryId: z.number() })).query(async ({ input }) => {
      return await db.getServicesByCategory(input.categoryId);
    }),

    create: adminProcedure
      .input(
        z.object({
          nome: z.string(),
          descricao: z.string().optional(),
          categoryId: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createService(input);
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          descricao: z.string().optional(),
          categoryId: z.number().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateService(id, data);
      }),
  }),

  // ============= INSPECTION SCOPE ROUTES =============
  inspectionScopes: router({
    list: publicProcedure.query(async () => {
      return await db.getAllInspectionScopes();
    }),

    listByType: publicProcedure.input(z.object({ tipo: z.string() })).query(async ({ input }) => {
      return await db.getInspectionScopesByType(input.tipo);
    }),

    create: adminProcedure
      .input(
        z.object({
          nome: z.string(),
          tipo: z.enum(["inmetro", "prefeitura_sp", "prefeitura_guarulhos", "mercosul", "tecnica"]),
          descricao: z.string().optional(),
          requerAutorizacaoDetran: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createInspectionScope(input);
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          tipo: z.enum(["inmetro", "prefeitura_sp", "prefeitura_guarulhos", "mercosul", "tecnica"]).optional(),
          descricao: z.string().optional(),
          requerAutorizacaoDetran: z.boolean().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateInspectionScope(id, data);
      }),
  }),

  // ============= INSPECTION TYPE ROUTES =============
  inspectionTypes: router({
    list: publicProcedure
      .input(z.object({ includeInactive: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getAllInspectionTypes(input?.includeInactive ?? false);
      }),

    listByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number().optional(), includeInactive: z.boolean().optional() }).optional())
      .query(async ({ input, ctx }) => {
        const tenantId = input?.tenantId ?? ctx.user.tenantId;
        if (!tenantId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Tenant não informado" });
        }
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        // Retorna apenas os tipos de inspeção que o tenant tem capacidade nas suas linhas
        return await db.getInspectionTypesByTenant(tenantId, input?.includeInactive ?? false);
      }),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const inspectionType = await db.getInspectionTypeById(input.id);
      if (!inspectionType) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Tipo de inspeção não encontrado" });
      }
      return inspectionType;
    }),

    create: adminProcedure
      .input(
        z.object({
          nome: z.string(),
          categoria: z.string().optional(),
          descricao: z.string().optional(),
          precoBase: z.number().int().nonnegative(),
          variacaoMaxima: z.number().int().min(0).optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createInspectionType({
          ...input,
          variacaoMaxima: input.variacaoMaxima ?? 0,
          ativo: input.ativo ?? true,
        });
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          categoria: z.string().optional(),
          descricao: z.string().optional(),
          precoBase: z.number().int().nonnegative().optional(),
          variacaoMaxima: z.number().int().min(0).optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateInspectionType(id, data);
      }),

    getTenants: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getInspectionTypeTenants(input.id);
    }),

    linkTenant: adminProcedure
      .input(z.object({ inspectionTypeId: z.number(), tenantId: z.number() }))
      .mutation(async ({ input }) => {
        return await db.linkInspectionTypeToTenant(input.inspectionTypeId, input.tenantId);
      }),

    unlinkTenant: adminProcedure
      .input(z.object({ inspectionTypeId: z.number(), tenantId: z.number() }))
      .mutation(async ({ input }) => {
        await db.unlinkInspectionTypeFromTenant(input.inspectionTypeId, input.tenantId);
        return { success: true };
      }),
  }),

  // ============= INSPECTION LINE ROUTES =============
  inspectionLines: router({
    listByTenant: tenantProcedure
      .input(
        z
          .object({
            tenantId: z.number().optional(),
            includeInactive: z.boolean().optional(),
            withCapabilities: z.boolean().optional(),
          })
          .optional()
      )
      .query(async ({ input, ctx }) => {
        const tenantId = input?.tenantId ?? ctx.user.tenantId;
        if (!tenantId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Tenant não informado" });
        }
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const lines = await db.getInspectionLinesByTenant(tenantId, input?.includeInactive ?? false);

        if (!input?.withCapabilities) {
          return lines;
        }

        const linesWithCapabilities = [];
        for (const line of lines) {
          const capabilities = await db.getCapabilitiesByInspectionLine(line.id);
          linesWithCapabilities.push({ ...line, capabilities });
        }
        return linesWithCapabilities;
      }),

    create: adminProcedure
      .input(
        z.object({
          tenantId: z.number(),
          nome: z.string().optional(),
          tipo: z.enum(["leve", "mista", "pesado", "motocicleta", "outra"]),
          descricao: z.string().optional(),
          quantidade: z.number().int().min(1).optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createInspectionLine({
          ...input,
          quantidade: input.quantidade ?? 1,
          ativo: input.ativo ?? true,
        });
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          tipo: z.enum(["leve", "mista", "pesado", "motocicleta", "outra"]).optional(),
          descricao: z.string().optional(),
          quantidade: z.number().int().min(1).optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateInspectionLine(id, data);
      }),
  }),

  // ============= INSPECTION LINE CAPABILITIES ROUTES =============
  inspectionLineCapabilities: router({
    listByLine: tenantProcedure.input(z.object({ inspectionLineId: z.number() })).query(async ({ input, ctx }) => {
      const line = await db.getInspectionLineById(input.inspectionLineId);
      if (!line) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Linha de inspeção não encontrada" });
      }
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== line.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getCapabilitiesByInspectionLine(input.inspectionLineId);
    }),

    create: adminProcedure
      .input(
        z.object({
          inspectionLineId: z.number(),
          inspectionTypeId: z.number(),
          capacidade: z.number().int().min(0).optional(),
          observacoes: z.string().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createInspectionLineCapability({
          ...input,
          capacidade: input.capacidade ?? 0,
          ativo: input.ativo ?? true,
        });
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          capacidade: z.number().int().min(0).optional(),
          observacoes: z.string().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateInspectionLineCapability(id, data);
      }),

    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return await db.deleteInspectionLineCapability(input.id);
    }),
  }),

  // ============= INSPECTION TYPE PRICING ROUTES =============
  inspectionTypePricing: router({
    listByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number().optional(), includeInactive: z.boolean().optional() }).optional())
      .query(async ({ input, ctx }) => {
        const tenantId = input?.tenantId ?? ctx.user.tenantId;
        if (!tenantId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Tenant não informado" });
        }
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        // Buscar apenas os tipos de inspeção que o tenant tem capacidade nas suas linhas
        const [types, prices] = await Promise.all([
          db.getInspectionTypesByTenant(tenantId, input?.includeInactive ?? false),
          db.getInspectionTypePricesByTenant(tenantId),
        ]);

        return types.map((type) => {
          const price = prices.find((p) => p.inspectionTypeId === type.id);
          return {
            type,
            pricing: price,
            faixa: {
              minimo: Math.max(0, type.precoBase - type.variacaoMaxima),
              maximo: type.precoBase + type.variacaoMaxima,
            },
            precoAtual: price?.preco ?? type.precoBase,
          };
        });
      }),

    setPrice: tenantProcedure
      .input(
        z.object({
          tenantId: z.number().optional(),
          inspectionTypeId: z.number(),
          preco: z.number().int().nonnegative(),
          observacoes: z.string().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const tenantId = input.tenantId ?? ctx.user.tenantId;
        if (!tenantId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Tenant não informado" });
        }
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const result = await db.setInspectionTypePrice({
          tenantId,
          inspectionTypeId: input.inspectionTypeId,
          preco: input.preco,
          observacoes: input.observacoes,
          ultimoAjustePor: ctx.user.id,
          ativo: input.ativo ?? true,
        });

        return result;
      }),
  }),

  // ============= PRICE CONFIGURATION ROUTES =============
  priceConfigurations: router({
    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      // Verify user has access to this tenant
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getPriceConfigurationsByTenant(input.tenantId);
    }),

    getByTenantAndService: publicProcedure
      .input(z.object({ tenantId: z.number(), serviceId: z.number() }))
      .query(async ({ input }) => {
        return await db.getPriceByTenantAndService(input.tenantId, input.serviceId);
      }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          serviceId: z.number(),
          preco: z.number(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.createPriceConfiguration(input);
      }),

    update: tenantProcedure
      .input(
        z.object({
          id: z.number(),
          preco: z.number().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updatePriceConfiguration(id, data);
      }),
  }),

  // ============= APPOINTMENT ROUTES =============
  appointments: router({
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getAppointmentById(input.id);
    }),

    listAll: adminProcedure.query(async () => {
      // Buscar todos os appointments para admin
      const tenants = await db.getAllTenants();
      const allAppointments = [];
      for (const tenant of tenants) {
        const appointments = await db.getAppointmentsByTenant(tenant.id);
        allAppointments.push(...appointments);
      }
      return allAppointments.sort((a, b) => b.dataAgendamento.getTime() - a.dataAgendamento.getTime());
    }),

    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getAppointmentsByTenant(input.tenantId);
    }),

    listByCustomer: protectedProcedure.input(z.object({ customerId: z.number() })).query(async ({ input }) => {
      return await db.getAppointmentsByCustomer(input.customerId);
    }),

    create: publicProcedure
      .input(
        z.object({
          tenantId: z.number(),
          customerId: z.number(),
          vehicleId: z.number(),
          inspectionScopeId: z.number(),
          detranAuthorizationId: z.number().optional(),
          dataAgendamento: z.date(),
          observacoes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createAppointment(input);
      }),

    update: tenantProcedure
      .input(
        z.object({
          id: z.number(),
          dataAgendamento: z.date().optional(),
          status: z.enum(["pendente", "confirmado", "realizado", "cancelado"]).optional(),
          observacoes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateAppointment(id, data);
      }),
  }),

  // ============= PAYMENT ROUTES =============
  payments: router({
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getPaymentById(input.id);
    }),

    getByAppointment: protectedProcedure.input(z.object({ appointmentId: z.number() })).query(async ({ input }) => {
      return await db.getPaymentByAppointment(input.appointmentId);
    }),

    createCharge: publicProcedure
      .input(
        z.object({
          appointmentId: z.number(),
          valorTotal: z.number(),
          metodoPagamento: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        // Buscar appointment e tenant
        const appointment = await db.getAppointmentById(input.appointmentId);
        if (!appointment) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Agendamento não encontrado" });
        }

        const tenant = await db.getTenantById(appointment.tenantId);
        if (!tenant) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Estabelecimento não encontrado" });
        }

        // Buscar customer
        const customer = await db.getCustomerById(appointment.customerId);
        if (!customer) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Cliente não encontrado" });
        }

        // Criar ou buscar customer no ASAAS
        const { criarOuBuscarCustomer, criarCobranca } = await import("../integrations/asaas");
        const asaasCustomerId = await criarOuBuscarCustomer({
          name: customer.nome,
          email: customer.email || undefined,
          phone: customer.telefone || undefined,
          cpfCnpj: customer.cpf,
          externalReference: customer.id.toString(),
        });

        // Buscar configuração de split (buscar qualquer split config para o tenant)
        const splitConfigs = await db.getSplitConfigurationsByTenant(tenant.id);
        const splitConfig = splitConfigs && splitConfigs.length > 0 ? splitConfigs[0] : null;

        // Calcular splits
        const splits = splitConfig
          ? [
              {
                walletId: tenant.asaasWalletId || "",
                percentualValue: splitConfig.percentualTenant,
              },
              {
                walletId: "PLATAFORMA_WALLET_ID", // TODO: Configurar wallet da plataforma
                percentualValue: splitConfig.percentualPlataforma,
              },
            ]
          : undefined;

        // Criar cobrança no ASAAS
        const asaasPayment = await criarCobranca({
          customer: asaasCustomerId,
          value: input.valorTotal,
          dueDate: new Date(appointment.dataAgendamento).toISOString().split("T")[0],
          description: `Agendamento #${appointment.id} - Inspeção Veicular`,
          billingType: (input.metodoPagamento?.toUpperCase() || "BOLETO") as any,
          split: splits as any,
        });

        // Salvar payment no banco
        const payment = await db.createPayment({
          appointmentId: input.appointmentId,
          valorTotal: input.valorTotal,
          metodoPagamento: input.metodoPagamento,
          asaasPaymentId: asaasPayment.id,
        });

        // Criar payment splits se houver
        if (splitConfig && splits) {
          // TODO: Criar payment splits
        }

        return {
          ...payment,
          asaasPayment,
          paymentUrl: asaasPayment.invoiceUrl || asaasPayment.bankSlipUrl || "#",
        };
      }),

    create: publicProcedure
      .input(
        z.object({
          appointmentId: z.number(),
          valorTotal: z.number(),
          metodoPagamento: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createPayment(input);
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["pendente", "processando", "aprovado", "recusado", "estornado"]).optional(),
          asaasPaymentId: z.string().optional(),
          dataPagamento: z.date().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updatePayment(id, data);
      }),

    consultarStatus: publicProcedure.input(z.object({ paymentId: z.number() })).query(async ({ input }) => {
      const payment = await db.getPaymentById(input.paymentId);
      if (!payment || !payment.asaasPaymentId) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Pagamento não encontrado ou sem ID ASAAS" });
      }

      const { consultarPagamento } = await import("../integrations/asaas");
      const asaasPayment = await consultarPagamento(payment.asaasPaymentId);

      // Atualizar status no banco se mudou
      if (asaasPayment.status !== payment.status) {
        const statusMap: Record<string, "pendente" | "processando" | "aprovado" | "recusado" | "estornado"> = {
          PENDING: "pendente",
          CONFIRMED: "processando",
          RECEIVED: "aprovado",
          REFUNDED: "estornado",
          OVERDUE: "pendente",
        };
        await db.updatePayment(input.paymentId, {
          status: statusMap[asaasPayment.status] || payment.status,
          dataPagamento: asaasPayment.paymentDate ? new Date(asaasPayment.paymentDate) : undefined,
        });
      }

      return asaasPayment;
    }),
  }),

  // ============= AUDIT LOG ROUTES =============
  auditLogs: router({
    list: adminProcedure
      .input(
        z
          .object({
            action: z.enum(["create", "update", "delete", "login", "logout"]).optional(),
            userId: z.number().optional(),
            tenantId: z.number().optional(),
            limit: z.number().optional().default(100),
          })
          .optional()
      )
      .query(async ({ input }) => {
        const filters = input || {};
        return await db.getAuditLogs(filters);
      }),

    listByTenant: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          limit: z.number().optional().default(100),
        })
      )
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getAuditLogsByTenant(input.tenantId, input.limit);
      }),
  }),

  // ============= PAYMENT SPLIT ROUTES =============
  paymentSplits: router({
    listByPayment: protectedProcedure.input(z.object({ paymentId: z.number() })).query(async ({ input }) => {
      return await db.getPaymentSplitsByPayment(input.paymentId);
    }),

    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getPaymentSplitsByTenant(input.tenantId);
    }),

    create: protectedProcedure
      .input(
        z.object({
          paymentId: z.number(),
          tenantId: z.number(),
          valor: z.number(),
          percentual: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createPaymentSplit(input);
      }),
  }),

  // ============= SPLIT CONFIGURATION ROUTES =============
  splitConfigurations: router({
    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getSplitConfigurationsByTenant(input.tenantId);
    }),

    getByTenantAndService: tenantProcedure
      .input(z.object({ tenantId: z.number(), serviceId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getSplitConfigByTenantAndService(input.tenantId, input.serviceId);
      }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          serviceId: z.number(),
          percentualTenant: z.number(),
          percentualPlataforma: z.number(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.createSplitConfiguration(input);
      }),

    update: tenantProcedure
      .input(
        z.object({
          id: z.number(),
          percentualTenant: z.number().optional(),
          percentualPlataforma: z.number().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateSplitConfiguration(id, data);
      }),
  }),

  // ============= AUDIT LOG ROUTES =============
  auditLogs: router({
    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number(), limit: z.number().optional() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getAuditLogsByTenant(input.tenantId, input.limit);
    }),

    listByUser: protectedProcedure.input(z.object({ userId: z.number(), limit: z.number().optional() })).query(async ({ input }) => {
      return await db.getAuditLogsByUser(input.userId, input.limit);
    }),

    create: protectedProcedure
      .input(
        z.object({
          userId: z.number(),
          tenantId: z.number().optional(),
          acao: z.string(),
          modulo: z.string(),
          entidade: z.string().optional(),
          entidadeId: z.number().optional(),
          dadosAntigos: z.any().optional(),
          dadosNovos: z.any().optional(),
          ipAddress: z.string().optional(),
          userAgent: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createAuditLog(input);
      }),
  }),

  // ============= WHATSAPP MESSAGE ROUTES =============
  whatsappMessages: router({
    listByCustomer: protectedProcedure.input(z.object({ customerId: z.number() })).query(async ({ input }) => {
      return await db.getWhatsappMessagesByCustomer(input.customerId);
    }),

    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getWhatsappMessagesByTenant(input.tenantId);
    }),

    create: protectedProcedure
      .input(
        z.object({
          customerId: z.number(),
          tenantId: z.number().optional(),
          appointmentId: z.number().optional(),
          mensagem: z.string(),
          direcao: z.enum(["enviada", "recebida"]),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createWhatsappMessage(input);
      }),
  }),

  // ============= FINANCIAL RECONCILIATION ROUTES =============
  financialReconciliations: router({
    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getFinancialReconciliationsByTenant(input.tenantId);
    }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          dataInicio: z.date(),
          dataFim: z.date(),
          valorTotal: z.number(),
          quantidadeTransacoes: z.number(),
          observacoes: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.createFinancialReconciliation(input);
      }),

    update: tenantProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["aberto", "fechado", "conciliado"]).optional(),
          observacoes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateFinancialReconciliation(id, data);
      }),
  }),

  // ============= REPORT ROUTES =============
  reports: router({
    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getReportsByTenant(input.tenantId);
    }),

    listAll: adminProcedure.query(async () => {
      return await db.getAllReports();
    }),

    create: protectedProcedure
      .input(
        z.object({
          tenantId: z.number().optional(),
          nome: z.string(),
          tipo: z.string(),
          parametros: z.any().optional(),
          dados: z.any().optional(),
          geradoPor: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createReport(input);
      }),

    getDailyAppointments: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          date: z.string(), // ISO date string
        })
      )
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const date = new Date(input.date);
        return await db.getAppointmentsByDate(input.tenantId, date);
      }),
  }),

  // ============= USER MANAGEMENT ROUTES =============
  users: router({
    list: adminProcedure.query(async () => {
      return await db.getAllUsers();
    }),

    listByTenant: tenantProcedure.input(z.object({ tenantId: z.number() })).query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getUsersByTenant(input.tenantId);
    }),

    getById: adminProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await db.getUserById(input.id);
    }),

    create: adminProcedure
      .input(
        z.object({
          name: z.string(),
          email: z.string().email(),
          password: z.string().min(6),
          role: z.enum(["admin", "operator", "user"]),
          tenantId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        // Verificar se já existe usuário com este email
        const existingUser = await db.getUserByEmail(input.email);
        if (existingUser) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Já existe um usuário com este e-mail" });
        }

        // Criar openId único baseado no email
        const openId = `manual-${input.email}`;
        
        // Verificar se já existe openId
        const existingByOpenId = await db.getUserByOpenId(openId);
        if (existingByOpenId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Já existe um usuário com este identificador" });
        }

        // Hash da senha
        const bcrypt = await import("bcrypt");
        const passwordHash = await bcrypt.hash(input.password, 10);

        const dbInstance = await db.getDb();
        if (!dbInstance) throw new Error("Database not available");

        await dbInstance.insert(users).values({
          openId,
          name: input.name,
          email: input.email,
          passwordHash,
          loginMethod: "manual",
          role: input.role,
          tenantId: input.tenantId ?? null,
        });

        const newUser = await db.getUserByOpenId(openId);
        if (!newUser) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao criar usuário" });
        }

        return newUser;
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          email: z.string().email().optional(),
          role: z.enum(["admin", "operator", "user"]).optional(),
          tenantId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const user = await db.getUserById(id);
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Usuário não encontrado" });
        }
        await db.upsertUser({
          openId: user.openId,
          name: data.name ?? user.name,
          email: data.email ?? user.email,
          role: data.role ?? user.role,
          tenantId: data.tenantId ?? user.tenantId,
        });
        return await db.getUserById(id);
      }),

    resetPassword: adminProcedure
      .input(
        z.object({
          userId: z.number(),
          password: z.string().min(6),
        })
      )
      .mutation(async ({ input }) => {
        const user = await db.getUserById(input.userId);
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Usuário não encontrado" });
        }

        const bcrypt = await import("bcrypt");
        const passwordHash = await bcrypt.hash(input.password, 10);

        await db.updateUserPassword(input.userId, passwordHash);
        return { success: true };
      }),
  }),

  // ============= COMPANY ROUTES =============
  companies: router({
    listByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getCompaniesByTenant(input.tenantId);
      }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          nome: z.string(),
          cnpj: z.string().optional(),
          razaoSocial: z.string().optional(),
          email: z.string().email().optional(),
          telefone: z.string().optional(),
          endereco: z.string().optional(),
          cidade: z.string().optional(),
          estado: z.string().optional(),
          cep: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.createCompany(input);
      }),

    update: tenantProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          cnpj: z.string().optional(),
          razaoSocial: z.string().optional(),
          email: z.string().email().optional(),
          telefone: z.string().optional(),
          endereco: z.string().optional(),
          cidade: z.string().optional(),
          estado: z.string().optional(),
          cep: z.string().optional(),
          ativo: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateCompany(id, data);
      }),
  }),

  // ============= INVOICE ROUTES =============
  invoices: router({
    listByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getInvoicesByTenant(input.tenantId);
      }),

    listPendingByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getPendingInvoicesByTenant(input.tenantId);
      }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          companyId: z.number(),
          valorTotal: z.number().int().nonnegative(),
          appointmentIds: z.array(z.number()), // IDs das inspeções para vincular
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        // Criar fatura
        const invoice = await db.createInvoice({
          tenantId: input.tenantId,
          companyId: input.companyId,
          valorTotal: input.valorTotal,
          status: "pendente",
        });

        // Vincular inspeções à fatura
        for (const appointmentId of input.appointmentIds) {
          const appointment = await db.getAppointmentById(appointmentId);
          if (appointment && appointment.inspectionTypeId) {
            // Buscar preço da inspeção
            const inspectionTypePrice = await db.getInspectionTypePrice(input.tenantId, appointment.inspectionTypeId);
            const valor = inspectionTypePrice?.preco || 0;
            await db.linkAppointmentToInvoice(invoice.id, appointmentId, valor);
          }
        }

        return invoice;
      }),

    close: tenantProcedure
      .input(
        z.object({
          invoiceId: z.number(),
          formaPagamento: z.enum(["pix", "boleto"]),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const invoice = await db.getInvoiceById(input.invoiceId);
        if (!invoice) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Fatura não encontrada" });
        }
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== invoice.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.closeInvoice(input.invoiceId, input.formaPagamento);
      }),

    getById: tenantProcedure.input(z.object({ id: z.number() })).query(async ({ input, ctx }) => {
      const invoice = await db.getInvoiceById(input.id);
      if (!invoice) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Fatura não encontrada" });
      }
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== invoice.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return invoice;
    }),
  }),

  // ============= TENANT USER ROUTES =============
  tenantUsers: router({
    listByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        // Buscar todos os usuários do tenant
        const allUsers = await db.getAllUsers();
        return allUsers.filter((u) => u.tenantId === input.tenantId && u.role === "operator");
      }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          name: z.string(),
          email: z.string().email(),
          password: z.string().min(6),
          groupId: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        // Verificar se o grupo pertence ao tenant
        if (input.groupId) {
          const group = await db.getUserGroupById(input.groupId);
          if (!group || group.tenantId !== input.tenantId) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "Grupo inválido" });
          }
        }

        const bcrypt = await import("bcrypt");
        const passwordHash = await bcrypt.hash(input.password, 10);

        const openId = `tenant-${input.tenantId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

        await db.upsertUser({
          openId,
          name: input.name,
          email: input.email,
          passwordHash,
          role: "operator",
          tenantId: input.tenantId,
          groupId: input.groupId,
        });

        const user = await db.getUserByEmail(input.email);
        return user;
      }),

    update: tenantProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          email: z.string().email().optional(),
          password: z.string().min(6).optional(),
          groupId: z.number().optional().nullable(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const user = await db.getUserById(input.id);
        if (!user || user.tenantId !== ctx.user.tenantId) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Usuário não encontrado" });
        }

        if (ctx.user.role !== "admin" && ctx.user.tenantId !== user.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        // Verificar se o grupo pertence ao tenant
        if (input.groupId !== undefined && input.groupId !== null) {
          const group = await db.getUserGroupById(input.groupId);
          if (!group || group.tenantId !== ctx.user.tenantId) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "Grupo inválido" });
          }
        }

        const updateData: any = {};
        if (input.name !== undefined) updateData.name = input.name;
        if (input.email !== undefined) updateData.email = input.email;
        if (input.groupId !== undefined) updateData.groupId = input.groupId;
        if (input.password) {
          const bcrypt = await import("bcrypt");
          updateData.passwordHash = await bcrypt.hash(input.password, 10);
        }

        await db.upsertUser({
          openId: user.openId,
          ...updateData,
        });

        return await db.getUserById(input.id);
      }),

    delete: tenantProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      const user = await db.getUserById(input.id);
      if (!user || user.tenantId !== ctx.user.tenantId) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Usuário não encontrado" });
      }
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== user.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      // Não deletar, apenas desativar ou remover do tenant
      // Por enquanto, apenas retornar sucesso
      return { success: true };
    }),
  }),

  // ============= USER GROUP ROUTES =============
  userGroups: router({
    listByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getUserGroupsByTenant(input.tenantId);
      }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          nome: z.string(),
          descricao: z.string().optional(),
          menuPaths: z.array(z.string()), // Array de paths dos menus permitidos
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const group = await db.createUserGroup({
          tenantId: input.tenantId,
          nome: input.nome,
          descricao: input.descricao || undefined,
          ativo: true,
        });

        // Definir permissões de menu
        await db.setGroupMenuPermissions(group.id, input.menuPaths);

        return { ...group, menuPaths: input.menuPaths };
      }),

    update: tenantProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          descricao: z.string().optional(),
          menuPaths: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const group = await db.getUserGroupById(input.id);
        if (!group) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Grupo não encontrado" });
        }
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== group.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const { id, menuPaths, ...data } = input;
        const updatedGroup = await db.updateUserGroup(id, data);

        // Atualizar permissões de menu se fornecidas
        if (menuPaths !== undefined) {
          await db.setGroupMenuPermissions(id, menuPaths);
        }

        const permissions = await db.getGroupMenuPermissions(id);
        return { ...updatedGroup, menuPaths: permissions.map((p) => p.menuPath) };
      }),

    getById: tenantProcedure.input(z.object({ id: z.number() })).query(async ({ input, ctx }) => {
      const group = await db.getUserGroupById(input.id);
      if (!group) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Grupo não encontrado" });
      }
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== group.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      const permissions = await db.getGroupMenuPermissions(input.id);
      return { ...group, menuPaths: permissions.map((p) => p.menuPath) };
    }),

    delete: tenantProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      const group = await db.getUserGroupById(input.id);
      if (!group) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Grupo não encontrado" });
      }
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== group.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      await db.deleteUserGroup(input.id);
      return { success: true };
    }),
  }),

  // ============= RECONCILIATION CONFIG ROUTES (ADMIN) =============
  reconciliationConfig: router({
    get: adminProcedure.query(async () => {
      return await db.getReconciliationConfig();
    }),

    upsert: adminProcedure
      .input(
        z.object({
          frequencia: z.enum(["diaria", "semanal", "mensal"]),
          diaSemana: z.number().optional(),
          diaMes: z.number().optional(),
          horario: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.upsertReconciliationConfig({
          frequencia: input.frequencia,
          diaSemana: input.diaSemana || null,
          diaMes: input.diaMes || null,
          horario: input.horario || null,
          ativo: true,
        });
      }),
  }),

  // ============= RECONCILIATION ROUTES =============
  reconciliations: router({
    listByTenant: tenantProcedure
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getReconciliationsByTenant(input.tenantId);
      }),

    getById: tenantProcedure.input(z.object({ id: z.number() })).query(async ({ input, ctx }) => {
      const reconciliation = await db.getReconciliationById(input.id);
      if (!reconciliation) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conciliação não encontrada" });
      }
      if (ctx.user.role !== "admin" && ctx.user.tenantId !== reconciliation.tenantId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return reconciliation;
    }),

    create: tenantProcedure
      .input(
        z.object({
          tenantId: z.number(),
          dataReferencia: z.string(), // ISO date string
          inspecoesGoverno: z.array(
            z.object({
              placa: z.string(),
              renavam: z.string().optional(),
              dataInspecao: z.string(),
              tipoInspecao: z.string().optional(),
              numeroProtocolo: z.string().optional(),
            })
          ),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.tenantId !== input.tenantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const dataRef = new Date(input.dataReferencia);
        // Buscar inspeções da plataforma do dia (já vem com dados relacionados)
        const inspecoesPlataforma = await db.getAppointmentsByDate(input.tenantId, dataRef);

        // Criar mapa de inspeções do governo por placa
        const inspecoesGovernoMap = new Map(
          input.inspecoesGoverno.map((ig) => [
            ig.placa.toUpperCase().replace(/[^A-Z0-9]/g, ""),
            ig,
          ])
        );

        // Comparar e encontrar divergências
        const inspecoesConciliadas: any[] = [];
        const inspecoesDivergentes: any[] = [];
        const inspecoesForaSistema: any[] = [];

        // Verificar inspeções da plataforma
        for (const ap of inspecoesPlataforma) {
          const veiculo = (ap as any).vehicle;
          if (veiculo && veiculo.placa) {
            const placaNormalizada = veiculo.placa.toUpperCase().replace(/[^A-Z0-9]/g, "");
            const inspecaoGoverno = inspecoesGovernoMap.get(placaNormalizada);

            if (inspecaoGoverno) {
              inspecoesConciliadas.push({
                appointmentId: ap.id,
                placa: veiculo.placa,
                plataforma: true,
                governo: true,
              });
              inspecoesGovernoMap.delete(placaNormalizada);
            } else {
              inspecoesDivergentes.push({
                appointmentId: ap.id,
                placa: veiculo.placa,
                plataforma: true,
                governo: false,
                motivo: "Inspeção na plataforma mas não encontrada no governo",
              });
            }
          } else if (ap.vehicleId) {
            // Veículo não encontrado mas tem ID
            inspecoesDivergentes.push({
              appointmentId: ap.id,
              placa: "N/A",
              plataforma: true,
              governo: false,
              motivo: "Veículo não encontrado na plataforma",
            });
          }
        }

        // Inspeções restantes no governo são "fora do sistema"
        for (const [, ig] of inspecoesGovernoMap) {
          inspecoesForaSistema.push({
            placa: ig.placa,
            dataInspecao: ig.dataInspecao,
            tipoInspecao: ig.tipoInspecao,
            numeroProtocolo: ig.numeroProtocolo,
            motivo: "Inspeção no governo mas não encontrada na plataforma",
          });
        }

        // Criar registro de conciliação
        const reconciliation = await db.createReconciliation({
          tenantId: input.tenantId,
          dataReferencia: dataRef,
          totalInspecoesPlataforma: inspecoesPlataforma.length,
          totalInspecoesGoverno: input.inspecoesGoverno.length,
          inspecoesConciliadas: inspecoesConciliadas.length,
          inspecoesDivergentes: inspecoesDivergentes.length,
          inspecoesForaSistema: inspecoesForaSistema.length,
          status: "concluida",
          detalhes: {
            conciliadas: inspecoesConciliadas,
            divergentes: inspecoesDivergentes,
            foraSistema: inspecoesForaSistema,
          },
        });

        return reconciliation;
      }),
  }),
});

export type AppRouter = typeof appRouter;
