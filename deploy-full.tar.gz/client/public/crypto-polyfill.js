// Polyfill crypto - DEVE ser carregado ANTES de qualquer outro script
// Versão que NÃO tenta sobrescrever window.crypto se já existir como getter
(function() {
  'use strict';
  console.log('[Crypto Polyfill JS] Carregando arquivo separado...');
  
  var polyfill = {
    getRandomValues: function(arr) {
      console.log('[Crypto Polyfill] getRandomValues chamado');
      if (!arr || arr.length === 0) return arr;
      for (var i = 0; i < arr.length; i++) {
        arr[i] = Math.floor(Math.random() * 256);
      }
      return arr;
    },
    randomUUID: function() {
      console.log('[Crypto Polyfill] randomUUID chamado');
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0;
        var v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
    subtle: {}
  };
  
  // Função para aplicar polyfill de forma segura
  function applyPolyfillSafely(ctx, name) {
    try {
      var descriptor = Object.getOwnPropertyDescriptor(ctx, name);
      
      // Se já existe e tem apenas getter, não tentar sobrescrever
      if (descriptor && descriptor.get && !descriptor.set) {
        console.log('[Crypto Polyfill JS] ' + name + ' já existe como getter, pulando...');
        return false;
      }
      
      // Tentar definir apenas se não existir ou for configurável
      if (!descriptor || descriptor.configurable) {
        try {
          Object.defineProperty(ctx, name, {
            value: polyfill,
            writable: true,
            configurable: true,
            enumerable: true
          });
          console.log('[Crypto Polyfill JS] ' + name + ' definido');
          return true;
        } catch(e) {
          // Se falhar, tentar atribuição direta
          try {
            ctx[name] = polyfill;
            console.log('[Crypto Polyfill JS] ' + name + ' definido via atribuição');
            return true;
          } catch(e2) {
            console.warn('[Crypto Polyfill JS] Não foi possível definir ' + name + ':', e2.message);
            return false;
          }
        }
      }
      return false;
    } catch(e) {
      console.warn('[Crypto Polyfill JS] Erro ao verificar ' + name + ':', e.message);
      return false;
    }
  }
  
  // Aplicar em todos os contextos possíveis
  var applied = [];
  if (typeof globalThis !== 'undefined') {
    if (applyPolyfillSafely(globalThis, 'crypto')) applied.push('globalThis');
  }
  if (typeof self !== 'undefined') {
    if (applyPolyfillSafely(self, 'crypto')) applied.push('self');
  }
  // window.crypto pode ter apenas getter, então verificar antes
  if (typeof window !== 'undefined') {
    try {
      var windowDesc = Object.getOwnPropertyDescriptor(window, 'crypto');
      if (!windowDesc || windowDesc.configurable) {
        if (applyPolyfillSafely(window, 'crypto')) applied.push('window');
      } else {
        console.log('[Crypto Polyfill JS] window.crypto não é configurável, usando globalThis.crypto');
      }
    } catch(e) {
      console.warn('[Crypto Polyfill JS] Erro ao verificar window.crypto:', e.message);
    }
  }
  
  console.log('[Crypto Polyfill JS] Aplicado em:', applied.join(', ') || 'nenhum');
  console.log('[Crypto Polyfill JS] Verificação final - crypto.getRandomValues?', 
    typeof globalThis !== 'undefined' && 
    globalThis.crypto && 
    typeof globalThis.crypto.getRandomValues === 'function');
})();

