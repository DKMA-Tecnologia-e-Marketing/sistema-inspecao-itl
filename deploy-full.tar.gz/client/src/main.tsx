// Polyfill crypto DEVE ser a primeira coisa - antes de qualquer import
// Garantir que crypto está disponível ANTES de qualquer código executar
if (typeof globalThis !== 'undefined' && !globalThis.crypto) {
  // @ts-ignore
  globalThis.crypto = {
    getRandomValues: function(arr: any) {
      if (!arr || arr.length === 0) return arr;
      for (let i = 0; i < arr.length; i++) {
        arr[i] = Math.floor(Math.random() * 256);
      }
      return arr;
    },
    randomUUID: function() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
  };
}

// Garantir que window.crypto aponta para globalThis.crypto (se não for getter)
if (typeof window !== 'undefined' && !window.crypto) {
  try {
    // @ts-ignore
    window.crypto = globalThis.crypto;
  } catch(e) {
    // window.crypto pode ser apenas getter, ignorar erro
  }
}

import React from "react";
import { trpc } from "@/lib/trpc";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink } from "@trpc/client";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

// URL da API - usar variável de ambiente em produção ou relativa em desenvolvimento
const getApiUrl = () => {
  if (import.meta.env.PROD) {
    // Em produção, usar a URL completa da API
    return import.meta.env.VITE_API_URL || "https://api.inspecionasp.com.br/api/trpc";
  }
  // Em desenvolvimento, usar URL relativa (será proxyada pelo Vite)
  return "/api/trpc";
};

// Garantir que crypto está disponível antes de criar o cliente tRPC
if (typeof globalThis !== 'undefined' && (!globalThis.crypto || typeof globalThis.crypto.getRandomValues !== 'function')) {
  // @ts-ignore
  globalThis.crypto = {
    getRandomValues: function(arr: any) {
      if (!arr || arr.length === 0) return arr;
      for (let i = 0; i < arr.length; i++) {
        arr[i] = Math.floor(Math.random() * 256);
      }
      return arr;
    },
    randomUUID: function() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
  };
}

const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      url: getApiUrl(),
      fetch(input, init) {
        // Garantir crypto antes de fazer fetch
        if (typeof globalThis !== 'undefined' && (!globalThis.crypto || typeof globalThis.crypto.getRandomValues !== 'function')) {
          // @ts-ignore
          globalThis.crypto = {
            getRandomValues: function(arr: any) {
              if (!arr || arr.length === 0) return arr;
              for (let i = 0; i < arr.length; i++) {
                arr[i] = Math.floor(Math.random() * 256);
              }
              return arr;
            },
          };
        }
        
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
        }).then(async (response) => {
          // Verificar se a resposta é HTML (erro do servidor)
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.includes("text/html")) {
            const text = await response.text();
            console.error("API retornou HTML em vez de JSON:", text.substring(0, 200));
            throw new Error("Servidor retornou uma página de erro. Verifique se o backend está rodando.");
          }
          return response;
        }).catch((error) => {
          console.error("Fetch error:", error);
          throw error;
        });
      },
    }),
  ],
});

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element not found");
}

try {
  createRoot(rootElement).render(
    <React.StrictMode>
      <trpc.Provider client={trpcClient} queryClient={queryClient}>
        <QueryClientProvider client={queryClient}>
          <App />
        </QueryClientProvider>
      </trpc.Provider>
    </React.StrictMode>
  );
} catch (error) {
  console.error("Error rendering app:", error);
  rootElement.innerHTML = `
    <div style="padding: 20px; font-family: Arial; color: red;">
      <h1>Erro ao renderizar aplicação</h1>
      <pre>${error instanceof Error ? error.stack : String(error)}</pre>
      <button onclick="window.location.reload()">Recarregar</button>
    </div>
  `;
}
