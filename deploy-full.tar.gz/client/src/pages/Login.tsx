import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Loader2, Shield, Building2, CheckCircle2 } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const loginMutation = trpc.auth.login.useMutation({
    onMutate: () => {
      console.log("[Login] Iniciando mutation...");
      console.log("[Login] crypto disponível?", typeof globalThis !== 'undefined' && typeof globalThis.crypto !== 'undefined');
      console.log("[Login] crypto.getRandomValues?", typeof globalThis !== 'undefined' && globalThis.crypto && typeof globalThis.crypto.getRandomValues === 'function');
    },
    onSuccess: (data) => {
      try {
        console.log("[Login] Sucesso - dados recebidos:", data);
        toast.success("Login realizado com sucesso!");
        // Redirecionar baseado no role
        if (data.user?.role === "admin") {
          window.location.href = "/admin";
        } else if (data.user?.role === "operator") {
          window.location.href = "/tenant";
        } else {
          window.location.href = "/";
        }
      } catch (error) {
        console.error("[Login] Erro ao processar sucesso:", error);
        toast.error("Erro ao processar login. Tente novamente.");
      }
    },
    onError: (error) => {
      console.error("[Login] Erro na mutation:", error);
      console.error("[Login] Stack:", error.stack);
      console.error("[Login] crypto disponível no momento do erro?", typeof globalThis !== 'undefined' && typeof globalThis.crypto !== 'undefined');
      toast.error(error.message || "Erro ao fazer login");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Preencha todos os campos");
      return;
    }
    loginMutation.mutate({ email, password });
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Lado esquerdo - Imagem e branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>
        
        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center items-center p-12 text-white">
          {/* Logo/Illustration */}
          <div className="mb-8">
            <img 
              src="/login-illustration.svg" 
              alt="Inspeciona SP" 
              className="w-full max-w-md h-auto"
              onError={(e) => {
                // Fallback se a imagem não carregar
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
              }}
            />
          </div>
          
          {/* Branding */}
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3 mb-6">
              <Shield className="h-12 w-12" />
              <h1 className="text-5xl font-bold tracking-tight">Inspeciona SP</h1>
            </div>
            <p className="text-xl text-blue-100 max-w-md">
              Sistema de gestão e inspeção para o estado de São Paulo
            </p>
            
            {/* Features */}
            <div className="mt-12 space-y-4 text-left max-w-sm">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-green-300 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold">Gestão Completa</h3>
                  <p className="text-sm text-blue-100">Controle total sobre inspeções e relatórios</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-green-300 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold">Relatórios Detalhados</h3>
                  <p className="text-sm text-blue-100">Gere relatórios profissionais em minutos</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-green-300 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold">Segurança e Confiabilidade</h3>
                  <p className="text-sm text-blue-100">Seus dados protegidos com criptografia avançada</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lado direito - Formulário de login */}
      <div className="flex-1 flex items-center justify-center p-4 lg:p-8 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="w-full max-w-md">
          <Card className="shadow-2xl border-0">
            <CardHeader className="space-y-4 text-center pb-8">
              {/* Mobile logo */}
              <div className="lg:hidden flex items-center justify-center gap-3 mb-4">
                <Shield className="h-10 w-10 text-blue-600" />
                <h1 className="text-3xl font-bold">Inspeciona SP</h1>
              </div>
              
              {/* Desktop title */}
              <div className="hidden lg:block">
                <CardTitle className="text-3xl font-bold">Bem-vindo de volta</CardTitle>
                <CardDescription className="text-base mt-2">
                  Entre com suas credenciais para acessar o sistema
                </CardDescription>
              </div>
              
              {/* Mobile title */}
              <div className="lg:hidden">
                <CardTitle className="text-2xl font-bold">Acesso ao Sistema</CardTitle>
                <CardDescription className="text-sm mt-2">
                  Entre com seu e-mail e senha
                </CardDescription>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">
                    E-mail
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={loginMutation.isPending}
                    required
                    className="h-11 text-base"
                    autoComplete="email"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">
                    Senha
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={loginMutation.isPending}
                    required
                    className="h-11 text-base"
                    autoComplete="current-password"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full h-11 text-base font-semibold bg-blue-600 hover:bg-blue-700" 
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Entrando...
                    </>
                  ) : (
                    <>
                      <Shield className="mr-2 h-4 w-4" />
                      Entrar
                    </>
                  )}
                </Button>
              </form>
              
              {/* Footer info */}
              <div className="pt-4 border-t">
                <p className="text-xs text-center text-muted-foreground">
                  Sistema de Inspeção - São Paulo
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}


