import TenantLayout from "@/components/TenantLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Search, User } from "lucide-react";
import { useState } from "react";

export default function TenantCustomers() {
  const { data: user } = trpc.auth.me.useQuery();
  const [searchTerm, setSearchTerm] = useState("");

  // Buscar agendamentos do tenant para extrair clientes
  const { data: appointments } = trpc.appointments.listAll.useQuery(
    { tenantId: user?.tenantId },
    { enabled: !!user?.tenantId }
  );

  // Extrair clientes únicos dos agendamentos
  const customerIds = new Set<number>();
  appointments?.forEach((apt) => {
    if (apt.customerId) customerIds.add(apt.customerId);
  });

  // Buscar dados dos clientes
  const customerQueries = Array.from(customerIds).map((id) =>
    trpc.customers.getById.useQuery({ id }, { enabled: !!id })
  );

  const customers = customerQueries
    .map((q) => q.data)
    .filter((c): c is NonNullable<typeof c> => c !== undefined);

  const filteredCustomers = customers.filter((customer) => {
    return (
      !searchTerm ||
      customer.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.cpf?.includes(searchTerm) ||
      customer.email?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <TenantLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Clientes</h2>
            <p className="text-muted-foreground">Gerencie os clientes do seu estabelecimento</p>
          </div>
        </div>

        {/* Search */}
        <Card>
          <CardHeader>
            <CardTitle>Buscar Cliente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome, CPF ou e-mail..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
          </CardContent>
        </Card>

        {/* Customers Table */}
        <Card>
          <CardHeader>
            <CardTitle>Clientes</CardTitle>
            <CardDescription>{filteredCustomers.length} cliente(s) encontrado(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {filteredCustomers.length === 0 ? (
              <div className="text-center py-8">
                <User className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Nenhum cliente encontrado</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Os clientes serão exibidos aqui conforme os agendamentos forem criados
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>CPF</TableHead>
                      <TableHead>E-mail</TableHead>
                      <TableHead>Telefone</TableHead>
                      <TableHead>Agendamentos</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCustomers.map((customer) => (
                      <TableRow key={customer.id}>
                        <TableCell className="font-medium">{customer.nome}</TableCell>
                        <TableCell>{customer.cpf}</TableCell>
                        <TableCell>{customer.email || "-"}</TableCell>
                        <TableCell>{customer.telefone || "-"}</TableCell>
                        <TableCell>-</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </TenantLayout>
  );
}

