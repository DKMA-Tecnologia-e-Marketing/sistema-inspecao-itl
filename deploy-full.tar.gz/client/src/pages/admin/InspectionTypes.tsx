import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Edit, Building2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

type FormState = {
  nome: string;
  categoria: string;
  descricao: string;
  precoBase: string;
  variacaoMaxima: string;
  ativo: boolean;
};

const defaultForm: FormState = {
  nome: "",
  categoria: "",
  descricao: "",
  precoBase: "0",
  variacaoMaxima: "0",
  ativo: true,
};

const formatCurrency = (value: number) => `R$ ${(value / 100).toFixed(2).replace(".", ",")}`;

export default function InspectionTypes() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [tenantsDialogOpen, setTenantsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [managingTenantsFor, setManagingTenantsFor] = useState<number | null>(null);
  const [form, setForm] = useState<FormState>(defaultForm);

  const utils = trpc.useUtils();
  const { data: inspectionTypes, isLoading } = trpc.inspectionTypes.list.useQuery({ includeInactive: true });
  const { data: tenants } = trpc.tenants.list.useQuery();
  
  const { data: linkedTenants, refetch: refetchLinkedTenants } = trpc.inspectionTypes.getTenants.useQuery(
    { id: managingTenantsFor || 0 },
    { enabled: !!managingTenantsFor }
  );

  const linkTenantMutation = trpc.inspectionTypes.linkTenant.useMutation({
    onSuccess: () => {
      toast.success("ITL vinculada com sucesso!");
      refetchLinkedTenants();
    },
    onError: (error) => toast.error("Erro ao vincular ITL: " + error.message),
  });

  const unlinkTenantMutation = trpc.inspectionTypes.unlinkTenant.useMutation({
    onSuccess: () => {
      toast.success("ITL desvinculada com sucesso!");
      refetchLinkedTenants();
    },
    onError: (error) => toast.error("Erro ao desvincular ITL: " + error.message),
  });

  const createType = trpc.inspectionTypes.create.useMutation({
    onSuccess: () => {
      toast.success("Tipo de inspeção criado com sucesso!");
      utils.inspectionTypes.list.invalidate();
      handleCloseDialog();
    },
    onError: (error) => toast.error("Erro ao criar tipo: " + error.message),
  });

  const updateType = trpc.inspectionTypes.update.useMutation({
    onSuccess: () => {
      toast.success("Tipo de inspeção atualizado!");
      utils.inspectionTypes.list.invalidate();
      handleCloseDialog();
    },
    onError: (error) => toast.error("Erro ao atualizar tipo: " + error.message),
  });

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingId(null);
    setForm(defaultForm);
  };

  const handleEdit = (typeId: number) => {
    const type = inspectionTypes?.find((t) => t.id === typeId);
    if (!type) return;

    setEditingId(typeId);
    setForm({
      nome: type.nome,
      categoria: type.categoria || "",
      descricao: type.descricao || "",
      precoBase: (type.precoBase / 100).toFixed(2),
      variacaoMaxima: (type.variacaoMaxima / 100).toFixed(2),
      ativo: type.ativo,
    });
    setDialogOpen(true);
  };

  const handleManageTenants = (typeId: number) => {
    setManagingTenantsFor(typeId);
    setTenantsDialogOpen(true);
  };

  const handleCloseTenantsDialog = () => {
    setTenantsDialogOpen(false);
    setManagingTenantsFor(null);
  };

  const toggleTenantLink = (tenantId: number, isLinked: boolean) => {
    if (!managingTenantsFor) return;

    if (isLinked) {
      unlinkTenantMutation.mutate({
        inspectionTypeId: managingTenantsFor,
        tenantId,
      });
    } else {
      linkTenantMutation.mutate({
        inspectionTypeId: managingTenantsFor,
        tenantId,
      });
    }
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const payload = {
      nome: form.nome.trim(),
      categoria: form.categoria.trim() || undefined,
      descricao: form.descricao.trim() || undefined,
      precoBase: Math.round(parseFloat(form.precoBase.replace(",", ".")) * 100) || 0,
      variacaoMaxima: Math.round(parseFloat(form.variacaoMaxima.replace(",", ".")) * 100) || 0,
      ativo: form.ativo,
    };

    if (!payload.nome) {
      toast.error("Informe um nome para o tipo de inspeção");
      return;
    }

    if (payload.precoBase < 0 || payload.variacaoMaxima < 0) {
      toast.error("Preços e variações devem ser valores positivos");
      return;
    }

    if (editingId) {
      updateType.mutate({
        id: editingId,
        ...payload,
      });
    } else {
      createType.mutate(payload);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Tipos de Inspeção</h2>
            <p className="text-muted-foreground">
              Configure os tipos de inspeção disponíveis, valores base e variações permitidas
            </p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={(open) => (!open ? handleCloseDialog() : setDialogOpen(true))}>
            <DialogTrigger asChild>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Tipo
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <DialogHeader>
                  <DialogTitle>{editingId ? "Editar Tipo de Inspeção" : "Novo Tipo de Inspeção"}</DialogTitle>
                  <DialogDescription>
                    Defina as informações do tipo e a faixa de preço permitida para as ITLs.
                  </DialogDescription>
                </DialogHeader>

                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome">Nome *</Label>
                    <Input
                      id="nome"
                      value={form.nome}
                      onChange={(e) => setForm((prev) => ({ ...prev, nome: e.target.value }))}
                      placeholder="Ex.: GNV - Inclusão"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="categoria">Categoria</Label>
                    <Input
                      id="categoria"
                      value={form.categoria}
                      onChange={(e) => setForm((prev) => ({ ...prev, categoria: e.target.value }))}
                      placeholder="Segurança Veicular, GNV..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="descricao">Descrição</Label>
                    <Textarea
                      id="descricao"
                      value={form.descricao}
                      onChange={(e) => setForm((prev) => ({ ...prev, descricao: e.target.value }))}
                      placeholder="Detalhes adicionais sobre o tipo de inspeção"
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="precoBase">Preço Base (R$)</Label>
                      <Input
                        id="precoBase"
                        type="number"
                        min="0"
                        step="0.01"
                        value={form.precoBase}
                        onChange={(e) => setForm((prev) => ({ ...prev, precoBase: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="variacaoMaxima">Variação Máxima (R$)</Label>
                      <Input
                        id="variacaoMaxima"
                        type="number"
                        min="0"
                        step="0.01"
                        value={form.variacaoMaxima}
                        onChange={(e) => setForm((prev) => ({ ...prev, variacaoMaxima: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <Label className="text-base">Ativo</Label>
                      <p className="text-sm text-muted-foreground">
                        Tipos inativos ficam ocultos para as ITLs.
                      </p>
                    </div>
                    <Switch checked={form.ativo} onCheckedChange={(checked) => setForm((prev) => ({ ...prev, ativo: checked }))} />
                  </div>
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={handleCloseDialog}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={createType.isPending || updateType.isPending}>
                    {editingId ? "Salvar alterações" : "Criar tipo"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Tipos cadastrados</CardTitle>
            <CardDescription>Visualize e ajuste os valores base e variações permitidas.</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="h-10 w-10 animate-spin rounded-full border-b-2 border-primary" />
              </div>
            ) : inspectionTypes && inspectionTypes.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Preço Base</TableHead>
                      <TableHead>Variação Permitida</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>ITLs Vinculadas</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {inspectionTypes.map((type) => (
                      <TableRow key={type.id}>
                        <TableCell className="font-medium">
                          <div className="flex flex-col">
                            <span>{type.nome}</span>
                            {type.descricao && <span className="text-sm text-muted-foreground">{type.descricao}</span>}
                          </div>
                        </TableCell>
                        <TableCell>{type.categoria || "-"}</TableCell>
                        <TableCell>{formatCurrency(type.precoBase)}</TableCell>
                        <TableCell>± {formatCurrency(type.variacaoMaxima)}</TableCell>
                        <TableCell>
                          {type.ativo ? (
                            <Badge variant="default">Ativo</Badge>
                          ) : (
                            <Badge variant="outline">Inativo</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleManageTenants(type.id)}
                          >
                            <Building2 className="mr-2 h-4 w-4" />
                            Gerenciar ITLs
                          </Button>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(type.id)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="py-8 text-center text-muted-foreground">Nenhum tipo de inspeção cadastrado ainda.</p>
            )}
          </CardContent>
        </Card>

        {/* Dialog para gerenciar ITLs vinculadas */}
        <Dialog open={tenantsDialogOpen} onOpenChange={(open) => (!open ? handleCloseTenantsDialog() : setTenantsDialogOpen(true))}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Gerenciar ITLs para este Tipo de Inspeção</DialogTitle>
              <DialogDescription>
                Selecione as ITLs que podem oferecer este tipo de inspeção. A variação de preço será respeitada.
              </DialogDescription>
            </DialogHeader>
            <div className="max-h-[400px] overflow-y-auto space-y-2 py-4">
              {tenants?.map((tenant) => {
                const isLinked = linkedTenants?.some((lt) => lt.tenantId === tenant.id) ?? false;
                return (
                  <div
                    key={tenant.id}
                    className="flex items-center space-x-2 rounded-lg border p-3 hover:bg-accent"
                  >
                    <Checkbox
                      id={`tenant-${tenant.id}`}
                      checked={isLinked}
                      onCheckedChange={() => toggleTenantLink(tenant.id, isLinked)}
                      disabled={linkTenantMutation.isPending || unlinkTenantMutation.isPending}
                    />
                    <label
                      htmlFor={`tenant-${tenant.id}`}
                      className="flex-1 cursor-pointer text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {tenant.nome}
                      {tenant.cnpj && <span className="ml-2 text-xs text-muted-foreground">({tenant.cnpj})</span>}
                    </label>
                  </div>
                );
              })}
              {(!tenants || tenants.length === 0) && (
                <p className="py-8 text-center text-muted-foreground">Nenhuma ITL cadastrada.</p>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCloseTenantsDialog}>
                Fechar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}



